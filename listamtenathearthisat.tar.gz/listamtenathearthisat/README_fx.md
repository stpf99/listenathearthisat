# HearThis Player — moduł audiofilski FX

Rozszerzenie odtwarzacza [HearThis.at](https://hearthis.at) o pełen łańcuch efektów audiofilskich przeniesiony z projektu **carbONmp** (`CarbonfX12g_v9_fixed.py`, PyQt) i zaadaptowany do **GTK4 + GStreamer**.

## Pliki

| Plik | Opis |
|------|------|
| `hearthis_fx.py`         | Moduł FX (2140 linii) — `FXChain`, `DynamicEQProcessor`, `MultibandLimiter`, `LimiterRouter`, `SceneManager`, `FXPanel`, `FXController`. |
| `hearthis_player.py`     | Załatana aplikacja główna (2085 linii) — przycisk **FX** w headerze, zwijany panel `Gtk.Revealer`, pipeline z `tee → spectrum` sidechain i wstrzykniętym łańcuchem FX. |
| `example_scene.json`     | Przykładowa wyeksportowana scena (format zgodny z `carbon_scenes.json`). |
| `README_fx.md`           | Ten plik. |

## Instalacja

Skopiuj oba pliki `.py` do tego samego katalogu (lub dodaj katalog do `PYTHONPATH`):

```bash
cp hearthis_fx.py hearthis_player.py /path/to/install/
python3 hearthis_player.py
```

Wymagane pakiety oprócz standardowych dla HearThis Player:

```bash
# GStreamer plugins (zwykle już zainstalowane z hearthis_player):
sudo apt install gstreamer1.0-plugins-base gstreamer1.0-plugins-good \
                 gstreamer1.0-plugins-bad gstreamer1.0-libav

# Kluczowe elementy:
#   equalizer-10bands, equalizer-3bands (gst-plugins-bad)
#   audiodynamic, audioecho, stereo, audiocheblimit (gst-plugins-base/good)
#   audiomixer, spectrum, capsfilter (gst-plugins-base)
```

Jeśli któryś z pluginów nie jest dostępny, moduł FX działa dalej w trybie degraded — brakujący efekt jest pomijany (graceful fallback).

## Architektura

### Pipeline audio (po patchu)

```
souphttpsrc / filesrc
  ! queue
  ! mpegaudioparse ! <dekoder MP3>
  ! audioconvert ! audioresample
  ! tee name=t allow-not-linked=true
      t. ! queue ! spectrum name=spectrum bands=128 ! fakesink       ← sidechain dla DynamicEQ AUTO
      t. ! audioconvert name=fx_in !
            [FXChain: q_fx → tape_sat → tape_gain → tape_tone → eq10
                     → sp_sat → sp_conv1 → sp_stereo → sp_conv2 → sp_echo
                     → ph_conv1 → ph_stereo → ph_conv2 → ph_echo
                     → conv_out]
            [MultibandLimiter POST_FX — tee→queues→5×filtr→limiter→mixer]
          ! volume name=vol ! queue ! pipewiresink sync=true
```

`MultibandLimiter` jest dynamicznie wstrzykiwany przez metodę `inject()` (rozłącza bezpośrednie `link`, wstawia tee→mixer). Trzy punkty:

| Punkt    | Lokalizacja w łańcuchu                  |
|----------|------------------------------------------|
| `INPUT`  | między `fx_in` a `q_fx` (przed wszystkim) |
| `POST_EQ`| między `eq10` a `sp_sat` (po EQ, przed Spatial) |
| `POST_FX`| między `conv_out` a `volume` (na końcu)   |

### Dynamic EQ — dwa tryby

Zgodnie z ustaleniami, moduł implementuje oba tryby przełączane w panelu (zakładka EQ → dropdown `Dynamic EQ`):

#### AUTO — SmartEQ spectrum-driven (FIXED)

**Błędy z carbONmp które naprawiono:**

1. **`chunk = len(spec)//10`** — gdy `len(spec)` nie dzieliło się przez 10, ostatnie pasma EQ dostawały mniej próbek spektrum (lub w ogóle). Fix: poprawny podział log-scale — każde pasmo EQ (32/64/125/250/500/1k/2k/4k/8k/16k Hz) dostaje magnitudy z właściwego zakresu częstotliwości (bin_lo = `f_lo / nyq * n_bands`).
2. **`tgt = [0.65]*10`** — target 65% pełnej skali był zbyt agresywny (kompresja loudness a nie EQ). Fix: target domyślnie **0.4** (umiarkowany), użytkownik może ustawić suwakiem.
3. **`sm = 0.9`** (smoothing) — powodowało pumping przy szybkich zmianach. Fix: domyślnie **0.95**.
4. **Korekcja max ±12 dB** — zbyt duża, wprowadzała artefakty intermodulacji. Fix: max **±6 dB**.

#### BANDS — klasyczny dynamic EQ

Wykorzystuje `MultibandLimiter` w punkcie `POST_EQ` — 5 niezależnych kompresorów na pasmach:

| Band    | Zakres Hz        | Default thr | Default ratio |
|---------|------------------|-------------|---------------|
| SUB     | 0–80             | 0.85        | 4.0:1         |
| BASS    | 80–250           | 0.80        | 3.0:1         |
| LO-MID  | 250–1500         | 0.75        | 2.5:1         |
| HI-MID  | 1500–6000        | 0.75        | 2.5:1         |
| AIR     | 6000+            | 0.70        | 3.0:1         |

Threshold i ratio per band konfigurowalne z panelu.

## Hi-res constraints (zgodnie z ustaleniami)

Wszystkie poniższe ograniczenia są **wymuszone** w module FX i w predefiniowanych scenach:

| Efekt          | Ograniczenie hi-res                                            |
|----------------|----------------------------------------------------------------|
| `lo_pass`      | Cutoff ≥ 20 kHz — filtry < 20 kHz są usuwane ze scen i z `CHAIN_ORDER` (Night Mode miał 16 kHz, Radio 18 kHz — usunięto). |
| Haas delay     | Max 15 ms (klamp w `set_spatial`, `set_phantom`, suwakach panelu). |
| Tape DRIVE     | Safe Mode domyślnie ON — DRIVE ≤ 40, WARMTH ≤ 50, COMP ≤ 30. Wyłączenie Safe Mode możliwe ręcznie, ale sceny wbudowane zawsze safe. |
| Phantom echo   | `ph_echo.intensity = 0` we wszystkich scenach wbudowanych (bypass). Echo dostępne ręcznie suwakiem w panelu. |

## Panel FX — zakładki

Aktywacja: przycisk **FX** w headerze (toggle) → panel rozwija się pod headerem (`Gtk.Revealer`, animacja `SLIDE_DOWN` 200 ms). Lazy build — panel tworzony dopiero gdy użytkownik pierwszy raz wciśnie FX.

| Zakładka | Elementy |
|----------|----------|
| **Tape** | `ACTIVE` checkbox, `🛡 Safe Mode` checkbox, 3 suwaki pionowe: `DRIVE`, `WARMTH`, `COMP` (0–100). |
| **EQ**   | Dropdown `Preset` (Flat/Club/Bass/Treble/Rock/Techno/Vocal), 10 suwaków pionowych (±12 dB, pasma 32 Hz – 16 kHz), dropdown `Dynamic EQ` (OFF/AUTO/BANDS), suwaki `Depth` / `Smooth` / `Target`. |
| **Spatial** | `ENABLE` checkbox, 3 suwaki: Stereo Width (0–3%), Haas Delay (0–15 ms hi-res), Sat Ratio. |
| **Phantom** | `ENABLE` checkbox, dropdown `Preset` (Off/Headphones/TV Wide/Podcast Mono/Concert/Studio), suwaki Width/Delay/Blend, Echo Intensity (0–1, hi-res default 0). |
| **Limiter** | 3 sekcje (INPUT, POST_EQ, POST_FX), każda: `ENABLE` checkbox + 5 pasm × 2 suwaki (Threshold 0.1–1.0, Ratio 1.0–10.0). |
| **Chain** | Gate, Compressor, Expander, Hi-Pass — każdy z `ENABLE` i parametrami. (`lo_pass` usunięty — hi-res.) |
| **Sceny** | Lista wbudowanych (read-only) i użytkownika z opisami. |

**Pasek scen** (góra panelu): dropdown wszystkich scen, przyciski `Zastosuj`, `Zapisz jako…`, `Eksportuj…`, `Importuj…`, `Usuń`.

## Sceny

### Wbudowane (read-only — hi-res fix)

Pochodzą z `BUILTIN_SCENES` z carbONmp v9_fixed, zaadaptowane przez `_hires_fix_scene()`:

- 🎙 **Podcast** — mowa, lekka korekcja
- 📺 **TV Audio** — wyrównanie dynamiki
- 🎵 **Music Hi-Fi** — czysto, przezroczyście, **hi-res passthrough** (domyślna scena startowa)
- 🎸 **Rock** — lekki punch, subtelna korekcja basu
- 🌙 **Night Mode** — ochrona dynamiki (lo_pass 16 kHz usunięty)
- 📻 **Radio** — wyrównanie pasma (lo_pass 18 kHz usunięty)
- ✨ **Custom** — punkt startowy hi-res

### Zapisywanie i eksport

- **Zapisz jako…** — zapisuje aktualny stan jako nową scenę w `~/.cache/hearthis_player/fx_scenes.json`
- **Eksportuj…** — `Gtk.FileChooser` → plik `.json` z formatem:
  ```json
  {"scene_name": "...", "exported_at": "...", "scene": {...}}
  ```
- **Importuj…** — wczytuje plik `.json` (nasz format lub bezpośrednio scene dict z `carbon_scenes.json`). Przy imporcie automatycznie aplikowany jest `_hires_fix_scene()`.

### Format sceny (zgodny z carbONmp)

```json
{
  "meta": {"icon": "...", "desc": "...", "created": "...", "modified": "..."},
  "volume": 80,
  "chain":   {"compressor": {"enabled": true, "params": {"threshold": 0.70, "ratio": 2.5}}, ...},
  "eq":      {"preset": "Rock", "bands": [2, 1, 0, -1, -1, 0, 0, 0, 1, 2]},
  "eq_dynamic": {"mode": "OFF", "depth": 0.5, "smoothing": 0.95, "target": 0.4},
  "tape":    {"active": true, "drive": 18, "warmth": 15, "comp": 10, "safe_mode": true},
  "spatial": {"active": true, "width": 0, "delay": 5, "saturation": 10},
  "phantom": {"active": false, "preset": "Studio", "mode": "crossfeed",
              "width": 5, "delay": 2, "blend": 5, "echo_intensity": 0.0},
  "limiter": {
    "INPUT":   {"enabled": false, "bands": [{"thr": 0.85, "ratio": 4.0}, ...]},
    "POST_EQ": {"enabled": false, "bands": [...]},
    "POST_FX": {"enabled": true,  "bands": [...]}
  }
}
```

Pola `eq_dynamic` i `phantom.echo_intensity` są rozszerzeniem HearThis FX — `carbon_scenes.json` (które ich nie ma) importuje się poprawnie (domyślne wartości).

## API modułu (dla programistów)

```python
from hearthis_fx import FXController

# W playerze (już zintegrowane):
self.fx_ctrl = FXController()
# Po zbudowaniu pipeline:
self.fx_ctrl.attach_to_pipeline(pipeline, fx_in_el, vol_el)
self.fx_ctrl.set_spectrum_element(spectrum_el)

# Panel GTK4:
panel = self.fx_ctrl.build_panel(app_ref=self)
revealer = Gtk.Revealer(child=panel)

# Bus message dispatcher (już w _on_msg):
self.fx_ctrl.on_bus_message(msg)

# Programowo zastosuj scenę:
self.fx_ctrl.apply_scene("🎵 Music Hi-Fi")
```

## Weryfikacja

- `python3 -c "import ast; ast.parse(open('hearthis_fx.py').read())"` → OK
- `python3 -c "import ast; ast.parse(open('hearthis_player.py').read())"` → OK
- `example_scene.json` — `json.load()` OK, wszystkie hi-res constraints PASS

## Znane ograniczenia

1. **Signal Chain modules (gate/compressor/expander/hipass)** — stan zapisywany w scenie, ale w obecnej wersji nie są dynamicznie wstrzykiwane do pipeline (wymaga `DSPAutoResolver` z carbONmp — do zrobienia w future patch). Przyciski `ENABLE` w panelu reagują, ale efekty są zapisywane tylko w scenie. Pełna dynamiczna budowa chain jak w carbONmp to osobny task.
2. **Spectrum sample rate** — element GStreamer `spectrum` nie raportuje sample rate w wiadomości. DynamicEQ AUTO zakłada 44.1 kHz dla mapowania log-scale pasm. Dla 96 kHz+ bin mapping będzie gęstszy w wysokich pasmach — algorytm nadal działa (prawidłowo grupuje magnitudy w pasmach EQ), ale rozdzielczość niskich pasm będzie niższa. Fix: zwiększyć `bands=256` w pipeline description gdy wiadomo że źródło jest hi-res.
3. **audiomixer** — wymaga `gst-plugins-base >= 1.16`. Na starszych systemach `MultibandLimiter` się wyłącza (fallback do braku limitowania — nie blokuje odtwarzania).

## Powiązane

- Inspiration / port source: `carbONmp/CarbonfX12g_v9_fixed.py` (PyQt)
- Target app: `listenathearthisat-main/hearthis_player.py` (GTK4)
- Licencja: hobby / używaj swobodnie. API i treści audio należą do hearthis.at.
