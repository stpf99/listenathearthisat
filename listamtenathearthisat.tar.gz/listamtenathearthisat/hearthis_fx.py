#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HearThis.at — moduł audiofilskich efektów FX
============================================

Łańcuch efektów przeniesiony z carbONmp (PyQt) do HearThis Player (GTK4):

  audioresample → tee ─┬─→ q_fx → tape_sat → tape_gain → tape_tone → eq10
                       │        → sp_sat → sp_conv1 → sp_stereo → sp_conv2 → sp_echo
                       │        → ph_conv1 → ph_stereo → ph_conv2 → ph_echo
                       │        → conv_out → [MultibandLimiter POST_FX] → volume → sink
                       └─→ q_sp → spectrum (sidechain dla DynamicEQ) → fakesink

Wbudowane sceny (BUILTIN_SCENES_HIRES) to sceny z carbONmp dostosowane do hi-res:
  • usunięto lo_pass < 20 kHz (obcinał słyszalne pasmo dla 24/96+)
  • Haas delay ograniczony do 15 ms (safe range)
  • Tape domyślnie w Safe Mode (DRIVE ≤ 40, WARMTH ≤ 50, COMP ≤ 30)
  • Phantom echo intensity=0 (bypass) we wszystkich scenach predefiniowanych

DynamicEQ ma dwa tryby zgodnie z wyborem:
  • AUTO  — spectrum-driven SmartEQ z fixem buga (chunk = len(spec)//10,
            tgt=[0.65]*10). Poprawiony podział log-scale 128 band → 10 band,
            target 0.4, smoothing 0.95, korekcja max ±6 dB.
  • BANDS — klasyczny dynamic EQ: 5 kompresorów (SUB/BASS/MID/HIGH/AIR)
            korzystających z MultibandLimiter POST_EQ z limiter-sidechain.

Sceny zapisywane w ~/.cache/hearthis_player/fx_scenes.json (format zgodny
z carbONmp — carbon_scenes.json można importować bezpośrednio).

Plik: hearthis_fx.py
Autor: port z carbONmp / CarbonfX12g_v9_fixed.py
Licencja: hobby / używaj swobodnie.
"""

import json
import math
import random
import threading
from copy import deepcopy
from datetime import datetime
from pathlib import Path

import gi

gi.require_version("Gtk", "4.0")
gi.require_version("Gst", "1.0")

from gi.repository import Gtk, Gst, GLib, GObject, Gdk  # noqa: E401


# ============================================================================
# STAŁE — presety, pasma limitera, sceny wbudowane (hi-res fix)
# ============================================================================

EQ_PRESETS = {
    "Flat":   [0] * 10,
    "Club":   [0, 0, 2, 3, 3, 3, 2, 0, 0, 0],
    "Bass":   [6, 5, 4, 2, 0, 0, 0, 0, 0, 0],
    "Treble": [0, 0, 0, 0, 0, 1, 3, 5, 5, 8],
    "Rock":   [4, 3, 1, -1, -2, -2, 0, 1, 3, 4],
    "Techno": [4, 3, 0, -2, -3, -2, 0, 2, 4, 4],
    "Vocal":  [-2, -3, -3, 1, 3, 3, 3, 1, 0, -1],
}

EQ_BAND_FREQS = [32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000]

# Pasma MultibandLimiter — identyczna jak carbONmp MBLIMIT_BANDS
MBLIMIT_BANDS = [
    {"name": "SUB",    "color": "#FF3333", "filter": "lo",   "f_lo": None,  "f_hi": 80.0,
     "threshold": 0.85, "ratio": 4.0},
    {"name": "BASS",   "color": "#FF8800", "filter": "band", "f_lo": 80.0,  "f_hi": 250.0,
     "threshold": 0.80, "ratio": 3.0},
    {"name": "LO-MID", "color": "#FFFF00", "filter": "band", "f_lo": 250.0, "f_hi": 1500.0,
     "threshold": 0.75, "ratio": 2.5},
    {"name": "HI-MID", "color": "#88FF00", "filter": "band", "f_lo": 1500.0,"f_hi": 6000.0,
     "threshold": 0.75, "ratio": 2.5},
    {"name": "AIR",    "color": "#00FFCC", "filter": "hi",   "f_lo": 6000.0,"f_hi": None,
     "threshold": 0.70, "ratio": 3.0},
]

PHANTOM_PRESETS = {
    "Off":          {"mode": "off",        "blend": 0, "width": 5,  "delay": 0,
                     "desc": "Brak przetwarzania — sygnał oryginalny"},
    "Headphones":   {"mode": "crossfeed",  "blend": 8, "width": 5,  "delay": 0,
                     "desc": "Crossfeed słuchawkowy — subtelny blend 8%"},
    "TV Wide":      {"mode": "haas",       "blend": 0, "width": 12, "delay": 6,
                     "desc": "Delikatne rozszerzenie TV — Haas 6ms, width 12%"},
    "Podcast Mono": {"mode": "haas",       "blend": 0, "width": 10, "delay": 8,
                     "desc": "Mono naturalnie — Haas 8ms, zachowuje środek"},
    "Concert":      {"mode": "haas",       "blend": 5, "width": 15, "delay": 12,
                     "desc": "Lekka scena koncertowa — Haas 12ms, width 15%"},
    "Studio":       {"mode": "crossfeed",  "blend": 5, "width": 5,  "delay": 2,
                     "desc": "Studio reference — minimalne crossfeed 5%"},
}

# Hi-res: Safe limits z carbONmp + Hard cap na Haas delay
SAFE_LIMITS = {"DRIVE": 40, "WARMTH": 50, "COMP": 30}
HIRES_HAAS_MAX_MS = 15
HIRES_LOPASS_MIN_HZ = 20000  # lo_pass poniżej tej wartości jest ignorowany

# Plik scen — zgodny z carbONmp (carbon_scenes.json można importować 1:1)
SCENE_FILE = Path.home() / ".cache" / "hearthis_player" / "fx_scenes.json"


def _hires_fix_scene(s: dict) -> dict:
    """Modyfikuje scenę z carbONmp tak, aby była hi-res bezpieczna:
       • usuwa lo_pass z chain (cutoff < 20 kHz)
       • klampuje Haas delay do 15 ms
       • wymusza Tape Safe Mode (drive ≤ 40, warmth ≤ 50, comp ≤ 30)
       • ustawia Phantom echo intensity=0 (bypass) — echo pominięte we wbudowanych
    """
    s = deepcopy(s)
    # chain: filtruj lo_pass < 20 kHz
    chain = s.get("chain", {}) or {}
    new_chain = {}
    for mid, st in chain.items():
        if mid == "lo_pass":
            cutoff = (st or {}).get("params", {}).get("cutoff", 20000.0)
            if cutoff < HIRES_LOPASS_MIN_HZ:
                continue  # pomiń — obcina słyszalne pasmo hi-res
        new_chain[mid] = st
    s["chain"] = new_chain
    # Tape Safe Mode
    tape = s.get("tape", {}) or {}
    tape["drive"]  = min(int(tape.get("drive", 10)),  SAFE_LIMITS["DRIVE"])
    tape["warmth"] = min(int(tape.get("warmth", 15)), SAFE_LIMITS["WARMTH"])
    tape["comp"]   = min(int(tape.get("comp", 5)),    SAFE_LIMITS["COMP"])
    tape["safe_mode"] = True
    s["tape"] = tape
    # Spatial: klamp Haas
    spat = s.get("spatial", {}) or {}
    spat["delay"] = min(int(spat.get("delay", 0)), HIRES_HAAS_MAX_MS)
    s["spatial"] = spat
    # Phantom: echo bypass (intensity=0) — sygnał bez powtórzeń
    ph = s.get("phantom", {}) or {}
    ph["echo_intensity"] = 0.0  # wymuszony bypass ph_echo
    s["phantom"] = ph
    # eq_dynamic default
    s.setdefault("eq_dynamic", {"mode": "OFF", "depth": 0.5, "smoothing": 0.95, "target": 0.4})
    return s


# Sceny wbudowane — bezpośrednia adaptacja BUILTIN_SCENES z carbONmp v9_fixed
# z zastosowanym hi-res fixem (patrz _hires_fix_scene powyżej).
_BUILTIN_RAW = {
    "🎙 Podcast": {
        "meta": {"icon": "🎙", "desc": "Mowa — lekka korekcja, naturalny głos"},
        "volume": 78,
        "chain": {
            "gate":       {"enabled": True,  "params": {"threshold": 0.02, "ratio": 3.0}},
            "compressor": {"enabled": True,  "params": {"threshold": 0.75, "ratio": 2.0}},
            "hi_pass":    {"enabled": True,  "params": {"cutoff": 80.0}},
        },
        "eq":      {"preset": "Vocal",   "bands": [-1, -2, -2, 0, 2, 2, 1, 0, 0, 0]},
        "tape":    {"active": False, "drive": 10, "warmth": 15, "comp": 5},
        "spatial": {"active": True,  "width": 0,  "delay": 4,  "saturation": 10},
        "phantom": {"active": True,  "preset": "Podcast Mono",
                    "mode": "haas", "width": 10, "delay": 8,  "blend": 0},
        "limiter": {"POST_FX": {"enabled": True,
                    "bands": [{"thr": 0.95, "ratio": 2.0}, {"thr": 0.92, "ratio": 1.8},
                              {"thr": 0.90, "ratio": 1.5}, {"thr": 0.90, "ratio": 1.5},
                              {"thr": 0.92, "ratio": 2.0}]}},
    },
    "📺 TV Audio": {
        "meta": {"icon": "📺", "desc": "TV — wyrównanie dynamiki, subtelne stereo"},
        "volume": 80,
        "chain": {
            "gate":       {"enabled": True,  "params": {"threshold": 0.02, "ratio": 2.5}},
            "compressor": {"enabled": True,  "params": {"threshold": 0.70, "ratio": 2.5}},
            "hi_pass":    {"enabled": True,  "params": {"cutoff": 60.0}},
        },
        "eq":      {"preset": "Flat",    "bands": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]},
        "tape":    {"active": False, "drive": 8,  "warmth": 10, "comp": 5},
        "spatial": {"active": True,  "width": 0,  "delay": 5,  "saturation": 10},
        "phantom": {"active": True,  "preset": "TV Wide",
                    "mode": "haas", "width": 12, "delay": 6,  "blend": 0},
        "limiter": {"POST_FX": {"enabled": True,
                    "bands": [{"thr": 0.93, "ratio": 2.5}, {"thr": 0.90, "ratio": 2.0},
                              {"thr": 0.90, "ratio": 1.8}, {"thr": 0.90, "ratio": 1.8},
                              {"thr": 0.93, "ratio": 2.5}]}},
    },
    "🎵 Music Hi-Fi": {
        "meta": {"icon": "🎵", "desc": "Muzyka — czysto, przezroczyście, bez efektów (hi-res passthrough)"},
        "volume": 80,
        "chain": {},
        "eq":      {"preset": "Flat",    "bands": [0] * 10},
        "tape":    {"active": False, "drive": 5,  "warmth": 5,  "comp": 5},
        "spatial": {"active": False, "width": 0,  "delay": 0,  "saturation": 10},
        "phantom": {"active": False, "preset": "Off",
                    "mode": "off", "width": 5,  "delay": 0,  "blend": 0},
        "limiter": {"POST_FX": {"enabled": True,
                    "bands": [{"thr": 0.98, "ratio": 1.2}, {"thr": 0.98, "ratio": 1.2},
                              {"thr": 0.98, "ratio": 1.2}, {"thr": 0.98, "ratio": 1.2},
                              {"thr": 0.98, "ratio": 1.2}]}},
    },
    "🎸 Rock": {
        "meta": {"icon": "🎸", "desc": "Rock — lekki punch, subtelna korekcja basu"},
        "volume": 78,
        "chain": {
            "compressor": {"enabled": True,  "params": {"threshold": 0.70, "ratio": 2.5}},
            "hi_pass":    {"enabled": True,  "params": {"cutoff": 40.0}},
        },
        "eq":      {"preset": "Rock",    "bands": [2, 1, 0, -1, -1, 0, 0, 0, 1, 2]},
        "tape":    {"active": True,  "drive": 18, "warmth": 15, "comp": 10},
        "spatial": {"active": True,  "width": 0,  "delay": 5,  "saturation": 10},
        "phantom": {"active": False, "preset": "Studio",
                    "mode": "crossfeed", "width": 5,  "delay": 2,  "blend": 5},
        "limiter": {"POST_FX": {"enabled": True,
                    "bands": [{"thr": 0.92, "ratio": 2.5}, {"thr": 0.90, "ratio": 2.5},
                              {"thr": 0.92, "ratio": 2.0}, {"thr": 0.92, "ratio": 2.0},
                              {"thr": 0.90, "ratio": 2.5}]}},
    },
    "🌙 Night Mode": {
        "meta": {"icon": "🌙", "desc": "Nocny — ochrona dynamiki, spokojne brzmienie (lo_pass 16k usunięty)"},
        "volume": 60,
        "chain": {
            "gate":       {"enabled": True,  "params": {"threshold": 0.02, "ratio": 2.0}},
            "compressor": {"enabled": True,  "params": {"threshold": 0.60, "ratio": 4.0}},
            # lo_pass 16000 usunięty — koliduje z hi-res (24/96+)
        },
        "eq":      {"preset": "Flat",    "bands": [1, 1, 0, 0, 0, 0, 0, 0, -1, -1]},
        "tape":    {"active": False, "drive": 5,  "warmth": 20, "comp": 8},
        "spatial": {"active": False, "width": 0,  "delay": 0,  "saturation": 10},
        "phantom": {"active": False, "preset": "Headphones",
                    "mode": "crossfeed", "width": 5,  "delay": 0,  "blend": 8},
        "limiter": {"POST_FX": {"enabled": True,
                    "bands": [{"thr": 0.75, "ratio": 4.0}, {"thr": 0.72, "ratio": 3.5},
                              {"thr": 0.75, "ratio": 3.0}, {"thr": 0.75, "ratio": 3.0},
                              {"thr": 0.72, "ratio": 4.0}]}},
    },
    "📻 Radio": {
        "meta": {"icon": "📻", "desc": "Radio — wyrównanie pasma, lekka korekcja (lo_pass 18k usunięty)"},
        "volume": 80,
        "chain": {
            "gate":       {"enabled": True,  "params": {"threshold": 0.02, "ratio": 2.5}},
            "compressor": {"enabled": True,  "params": {"threshold": 0.70, "ratio": 3.0}},
            "hi_pass":    {"enabled": True,  "params": {"cutoff": 80.0}},
            # lo_pass 18000 usunięty — koliduje z hi-res
        },
        "eq":      {"preset": "Vocal",   "bands": [-1, -1, -1, 0, 1, 1, 0, 0, 0, 0]},
        "tape":    {"active": False, "drive": 8,  "warmth": 10, "comp": 5},
        "spatial": {"active": True,  "width": 0,  "delay": 3,  "saturation": 10},
        "phantom": {"active": True,  "preset": "Studio",
                    "mode": "crossfeed", "width": 5,  "delay": 2,  "blend": 5},
        "limiter": {"POST_FX": {"enabled": True,
                    "bands": [{"thr": 0.93, "ratio": 2.0}, {"thr": 0.92, "ratio": 2.0},
                              {"thr": 0.92, "ratio": 1.8}, {"thr": 0.92, "ratio": 1.8},
                              {"thr": 0.93, "ratio": 2.0}]}},
    },
    "✨ Custom": {
        "meta": {"icon": "✨", "desc": "Twoje własne ustawienia (punkt startowy hi-res)"},
        "volume": 80,
        "chain": {},
        "eq":      {"preset": "Flat", "bands": [0] * 10},
        "tape":    {"active": False, "drive": 10, "warmth": 10, "comp": 5},
        "spatial": {"active": False, "width": 0,  "delay": 0,  "saturation": 10},
        "phantom": {"active": False, "preset": "Off",
                    "mode": "off", "width": 5,  "delay": 0,  "blend": 0},
        "limiter": {},
    },
}

# Po fixie — gotowe sceny wbudowane (read-only dla użytkownika)
BUILTIN_SCENES_HIRES = {n: _hires_fix_scene(s) for n, s in _BUILTIN_RAW.items()}


# ============================================================================
# Helper — tworzenie elementów GStreamer z fallbackiem
# ============================================================================
def mkgst(plugin_name: str, element_name: str, props: dict | None = None):
    """Tworzy element GStreamer; None jeśli plugin niedostępny (graceful fallback)."""
    try:
        el = Gst.ElementFactory.make(plugin_name, element_name)
    except Exception as e:
        print(f"[FX] Brak pluginu {plugin_name} ({element_name}): {e}")
        return None
    if el is None:
        print(f"[FX] Brak pluginu {plugin_name} ({element_name})")
        return None
    if props:
        for k, v in props.items():
            try:
                el.set_property(k, float(v) if isinstance(v, float) else v)
            except Exception as e:
                print(f"[FX] {element_name}.{k}={v}: {e}")
    return el


def _lnk(a, b):
    """Link dwóch elementów z raportowaniem błędów. None-safe."""
    if a is None or b is None:
        return False
    if not a.link(b):
        print(f"[FX] link fail: {a.get_name()} → {b.get_name()}")
        return False
    return True


def _unlink_full(a, b):
    """Rozłącza src a od sink b jeśli połączone."""
    if a is None or b is None:
        return
    sp = a.get_static_pad("src")
    if sp and sp.is_linked():
        peer = sp.get_peer()
        if peer and peer.get_parent() == b:
            sp.unlink(peer)


# ============================================================================
# FXState — model parametrów
# ============================================================================
class FXState:
    """Aktualny stan wszystkich parametrów FX — niezależny od GStreamer.
    Przechowuje wartości nawet gdy pipeline nie istnieje (np. między utworami)."""

    DEFAULT_LIMITER_BANDS = [
        {"thr": 0.85, "ratio": 4.0},
        {"thr": 0.80, "ratio": 3.0},
        {"thr": 0.75, "ratio": 2.5},
        {"thr": 0.75, "ratio": 2.5},
        {"thr": 0.70, "ratio": 3.0},
    ]

    def __init__(self):
        self.tape = {"active": False, "drive": 10, "warmth": 15, "comp": 5, "safe_mode": True}
        self.eq = {"preset": "Flat", "bands": [0] * 10}
        self.eq_dynamic = {"mode": "OFF", "depth": 0.5, "smoothing": 0.95, "target": 0.4}
        self.spatial = {"active": False, "width": 0, "delay": 0, "saturation": 10}
        self.phantom = {"active": False, "preset": "Off",
                        "mode": "off", "width": 5, "delay": 0, "blend": 0,
                        "echo_intensity": 0.0}
        # AUTO PROTECT — domyślnie ON. Limiter sam monitoruje pasma i dostosowuje
        # threshold/ratio. Chroni użytkownika który nie wie co robi (hi-res safe).
        self.limiter_auto_protect = True
        self.limiter = {
            pid: {"enabled": False, "bands": deepcopy(self.DEFAULT_LIMITER_BANDS)}
            for pid in ("INPUT", "POST_EQ", "POST_FX")
        }
        self.chain = {}  # signal chain modules — {mid: {"enabled": bool, "params": {...}}}

    # ── Serializacja ──────────────────────────────────────────────────────
    def to_dict(self) -> dict:
        return {
            "tape":        deepcopy(self.tape),
            "eq":          deepcopy(self.eq),
            "eq_dynamic":  deepcopy(self.eq_dynamic),
            "spatial":     deepcopy(self.spatial),
            "phantom":     deepcopy(self.phantom),
            "limiter":     deepcopy(self.limiter),
            "limiter_auto_protect": self.limiter_auto_protect,
            "chain":       deepcopy(self.chain),
        }

    def from_dict(self, d: dict):
        d = d or {}
        if "tape" in d:       self.tape.update(d["tape"])
        if "eq" in d:         self.eq.update(d["eq"])
        if "eq_dynamic" in d: self.eq_dynamic.update(d["eq_dynamic"])
        if "spatial" in d:    self.spatial.update(d["spatial"])
        if "phantom" in d:    self.phantom.update(d["phantom"])
        if "limiter" in d:
            for pid, st in (d["limiter"] or {}).items():
                if pid in self.limiter:
                    self.limiter[pid].update(st)
        if "limiter_auto_protect" in d:
            self.limiter_auto_protect = bool(d["limiter_auto_protect"])
        if "chain" in d:      self.chain = deepcopy(d["chain"])
        # Hi-res sanity — klamp wartości do bezpiecznych zakresów
        # Tape: Safe Mode (DRIVE≤40, WARMTH≤50, COMP≤30) + hard cap 50 (max slider)
        self.tape["drive"]  = min(int(self.tape.get("drive", 10)),  50)
        self.tape["warmth"] = min(int(self.tape.get("warmth", 15)), 50)
        self.tape["comp"]   = min(int(self.tape.get("comp", 5)),    50)
        if self.tape.get("safe_mode", True):
            self.tape["drive"]  = min(self.tape["drive"],  SAFE_LIMITS["DRIVE"])
            self.tape["warmth"] = min(self.tape["warmth"], SAFE_LIMITS["WARMTH"])
            self.tape["comp"]   = min(self.tape["comp"],   SAFE_LIMITS["COMP"])
        # Spatial: klamp do nowych max (width≤30, delay≤7 dla UI, sat≤45)
        self.spatial["width"]      = min(int(self.spatial.get("width", 0)),      30)
        self.spatial["delay"]      = min(int(self.spatial.get("delay", 0)),      HIRES_HAAS_MAX_MS)
        self.spatial["saturation"] = min(max(int(self.spatial.get("saturation", 10)), 10), 45)
        # Phantom: klamp do halved ranges
        self.phantom["width"]  = min(int(self.phantom.get("width", 5)),  10)
        self.phantom["delay"]  = min(int(self.phantom.get("delay", 0)),  HIRES_HAAS_MAX_MS)
        self.phantom["blend"]  = min(int(self.phantom.get("blend", 0)),  25)
        self.phantom["echo_intensity"] = min(float(self.phantom.get("echo_intensity", 0.0)), 0.5)
        # Limiter: klamp ratio ≤ 5.0 (halved z 10.0); threshold pozostaje 0.1-1.0
        for pid in ("INPUT", "POST_EQ", "POST_FX"):
            for b in self.limiter[pid].get("bands", []):
                if "ratio" in b:
                    b["ratio"] = min(float(b["ratio"]), 5.0)
                if "thr" in b:
                    b["thr"] = max(0.1, min(float(b["thr"]), 1.0))


# ============================================================================
# FXChain — topologia GStreamer + sterowanie elementami
# ============================================================================
class FXChain:
    """
    Buduje stały łańcuch efektów między dwoma elementami w pipeline.

    Topologia:
      entry_el → q_fx → tape_sat → tape_gain → tape_tone → eq10
               → sp_sat → sp_conv1 → sp_stereo → sp_conv2 → sp_echo
               → ph_conv1 → ph_stereo → ph_conv2 → ph_echo
               → conv_out → exit_el

    Elementy są zawsze obecne w pipeline (z wartościami neutralnymi gdy bypass).
    Spectrum sidechain (dla DynamicEQ AUTO) jest osobną gałęzią z tee — caller
    buduje tee + spectrum sam i podaje spectrum element do set_spectrum().
    """

    def __init__(self):
        # GStreamer elements (None gdy plugin niedostępny)
        self.q_fx = None
        self.tape_sat = None
        self.tape_gain = None
        self.tape_tone = None
        self.eq = None
        self.sp_sat = None
        self.sp_conv1 = None
        self.sp_stereo = None
        self.sp_conv2 = None
        self.sp_echo = None
        self.ph_conv1 = None
        self.ph_stereo = None
        self.ph_conv2 = None
        self.ph_echo = None
        self.conv_out = None
        # Anchory w pipeline (ustawiane przez build)
        self.entry_el = None
        self.exit_el = None
        self.pipeline = None
        # Spectrum sidechain (caller-set)
        self.spectrum = None

    # ── Budowanie łańcucha ──────────────────────────────────────────────────
    def build(self, pipeline, entry_el, exit_el):
        """
        Tworzy wszystkie elementy FX i łączy je między entry_el a exit_el.
        entry_el musi mieć jeden src pad; exit_el musi mieć jeden sink pad.
        Zwraca True gdy łańcuch zbudowany (choć częściowo — brak pluginów pociąga None).

        UWAGA: parse_launch zstawia bezpośredni link entry_el → exit_el (np.
        fx_in → vol). Zanim dodamy własne elementy, musimy ten link rozłączyć
        — inaczej fx_in.src i vol.sink są zajęte i nasze _lnk() zawiedzie.
        """
        self.pipeline = pipeline
        self.entry_el = entry_el
        self.exit_el  = exit_el

        # KLUCZOWE: najpierw rozłącz bezpośredni link entry → exit zostawiony
        # przez Gst.parse_launch(). Bez tego src pad entry i sink pad exit są
        # już zajęte i żadne nasze linki się nie udadzą.
        _unlink_full(entry_el, exit_el)

        # Tape Saturation
        self.tape_sat  = mkgst("audiodynamic", "tape_sat", {
            "characteristics": "soft-knee", "mode": "compressor",
            "threshold": 1.0, "ratio": 1.0,
        })
        self.tape_gain = mkgst("volume", "tape_gain", {"volume": 1.0})
        self.tape_tone = mkgst("equalizer-3bands", "tape_tone")

        # EQ 10-band
        self.eq = mkgst("equalizer-10bands", "eq10")

        # Spatial
        self.sp_sat    = mkgst("audiodynamic", "sp_sat", {
            "characteristics": "hard-knee", "mode": "compressor",
            "threshold": 0.0, "ratio": 1.0,
        })
        self.sp_conv1  = mkgst("audioconvert", "sp_conv1")
        self.sp_stereo = mkgst("stereo", "sp_stereo", {"stereo": 1.0})
        self.sp_conv2  = mkgst("audioconvert", "sp_conv2")
        self.sp_echo   = mkgst("audioecho", "sp_echo",
                               {"delay": 1, "intensity": 0.0, "feedback": 0.0})

        # Phantom Stereo
        self.ph_conv1  = mkgst("audioconvert", "ph_conv1")
        self.ph_stereo = mkgst("stereo", "ph_stereo", {"stereo": 1.0})
        self.ph_conv2  = mkgst("audioconvert", "ph_conv2")
        self.ph_echo   = mkgst("audioecho", "ph_echo",
                               {"delay": 1, "intensity": 0.0, "feedback": 0.0})

        # Output converter
        self.conv_out  = mkgst("audioconvert", "fx_conv_out")

        # Kolejka wejściowa FX (asynchroniczny bufor dla całego łańcucha)
        self.q_fx = mkgst("queue", "q_fx",
                          {"max-size-buffers": 0, "max-size-time": 0, "max-size-bytes": 0})

        # Rejestr elementów — pomijamy None (fallback gdy plugin niedostępny)
        elements_in_order = [
            self.q_fx,
            self.tape_sat, self.tape_gain, self.tape_tone,
            self.eq,
            self.sp_sat, self.sp_conv1, self.sp_stereo, self.sp_conv2, self.sp_echo,
            self.ph_conv1, self.ph_stereo, self.ph_conv2, self.ph_echo,
            self.conv_out,
        ]
        present = [el for el in elements_in_order if el is not None]
        for el in present:
            pipeline.add(el)

        # Link: entry → (q_fx → ... → conv_out) → exit
        # Pomijamy None w łańcuchu — linkujemy tylko obecne elementy po kolei.
        chain = [entry_el] + present + [exit_el]
        ok = True
        for a, b in zip(chain, chain[1:]):
            if not _lnk(a, b):
                ok = False
        if ok:
            print("[FX] łańcuch zbudowany:", " → ".join(
                el.get_name() for el in [entry_el] + present + [exit_el]))
        else:
            print("[FX] UWAGA: nie wszystkie linki się udały — sprawdź logi GStreamer")
        return ok

    def set_spectrum(self, spectrum_el):
        """Przekazuje element spectrum (tworzony przez caller w osobnej gałęzi tee)
        do użytku przez DynamicEQProcessor."""
        self.spectrum = spectrum_el

    # ── Wymuszenie stanu neutralnego (hi-res passthrough) ───────────────────
    def apply_neutral(self):
        """Ustawia wszystkie efekty w tryb bypass (sygnał oryginalny)."""
        # Tape
        self._set(self.tape_sat,  "threshold", 1.0)
        self._set(self.tape_sat,  "ratio",     1.0)
        self._set(self.tape_gain, "volume",    1.0)
        self._set(self.tape_tone, "band0",     0.0)
        self._set(self.tape_tone, "band2",     0.0)
        # EQ — wszystkie pasma 0 dB
        for i in range(10):
            self._set(self.eq, f"band{i}", 0.0)
        # Spatial
        self._set(self.sp_sat,    "ratio",     1.0)
        self._set(self.sp_sat,    "threshold", 1.0)
        self._set(self.sp_stereo, "stereo",    1.0)
        self._set(self.sp_echo,   "intensity", 0.0)
        self._set(self.sp_echo,   "delay",     1)
        # Phantom
        self._set(self.ph_stereo, "stereo",    1.0)
        self._set(self.ph_echo,   "intensity", 0.0)
        self._set(self.ph_echo,   "delay",     1)

    # ── Tape ──────────────────────────────────────────────────────────────
    def set_tape(self, params: dict):
        active = params.get("active", False)
        if not active:
            self._set(self.tape_sat,  "threshold", 1.0)
            self._set(self.tape_sat,  "ratio",     1.0)
            self._set(self.tape_gain, "volume",    1.0)
            self._set(self.tape_tone, "band0",     0.0)
            self._set(self.tape_tone, "band2",     0.0)
            return
        drive  = self._safe_clamp("DRIVE",  int(params.get("drive",  50)))
        warmth = self._safe_clamp("WARMTH", int(params.get("warmth", 30)))
        comp   = self._safe_clamp("COMP",   int(params.get("comp",   20)))
        safe   = bool(params.get("safe_mode", True))
        # Tape drive → threshold + gain makeup
        self._set(self.tape_sat,  "threshold", 0.9 - (drive / 100 * 0.8))
        self._set(self.tape_gain, "volume",    1.0 + (drive / 100 * 0.8))
        # Warmth → tonal tilt (boost lows, cut highs)
        self._set(self.tape_tone, "band0", warmth / 100 * 4.0)
        self._set(self.tape_tone, "band2", -(warmth / 100 * 3.0))
        # Comp → ratio
        self._set(self.tape_sat, "ratio", 1.0 + (comp / 100 * 9.0))

    @staticmethod
    def _safe_clamp(name: str, v: int) -> int:
        """Klampuje wartość pokrętła do SAFE_LIMITS (jeśli safe_mode włączony w params)."""
        # Wywoływana bez kontekstu safe_mode — hi-res default = zawsze safe
        return max(0, min(v, SAFE_LIMITS.get(name, 100)))

    # ── EQ ────────────────────────────────────────────────────────────────
    def set_eq_band(self, i: int, val: float):
        self._set(self.eq, f"band{i}", float(val))

    def set_eq_all(self, bands: list):
        for i, v in enumerate(bands[:10]):
            self.set_eq_band(i, v)

    # ── Spatial ───────────────────────────────────────────────────────────
    def set_spatial(self, params: dict):
        """Spatial FX — ZAWSZE aktywny w pipeline (brak checkboxa ENABLE).
        Sterowanie odbywa się wyłącznie przez suwaki width / delay / saturation.
        Domyślne wartości (width=0, delay=0, sat=10) dają passthrough:
          • stereo plugin: 0.0 = brak efektu (passthrough, czysto)
          • audioecho: intensity=0, delay=1ns = brak echa
          • audiodynamic: ratio=1.0, threshold=1.0 = brak kompresji
        Pole `active` w params jest ignorowane (zachowane w scenach dla
        kompatybilności z formatem carbon_scenes.json)."""
        width  = int(params.get("width",  0))
        delay  = min(int(params.get("delay", 0)), HIRES_HAAS_MAX_MS)  # klamp hi-res
        sat    = int(params.get("saturation", 10))
        # Width — suwak 0-60 → stereo 0.0-0.03 (3% max — bezpieczny zakres)
        # stereo plugin: 0.0 = passthrough, 1.0 = maksymalne poszerzenie (trzeszczy!)
        self._set(self.sp_stereo, "stereo", width * 0.0005)
        # Haas — delay w ns, intensity gdy delay>0
        ns = max(1, delay * 1_000_000)
        intensity = 0.0 if delay == 0 else 0.35
        self._set(self.sp_echo, "delay", ns)
        self._set(self.sp_echo, "intensity", intensity)
        # Saturation — ratio + threshold
        ratio = sat / 10.0  # 1.0..8.0
        thr   = 0.85 if ratio > 1.5 else 1.0
        self._set(self.sp_sat, "ratio", ratio)
        self._set(self.sp_sat, "threshold", thr)

    # ── Phantom Stereo ────────────────────────────────────────────────────
    def set_phantom(self, params: dict):
        active = params.get("active", False)
        # ph_echo zawsze bypass domyślnie (hi-res — brak powtórzeń)
        echo_intensity = float(params.get("echo_intensity", 0.0))
        self._set(self.ph_echo, "intensity", echo_intensity)
        self._set(self.ph_echo, "delay", 1)
        if not active:
            self._set(self.ph_stereo, "stereo", 1.0)
            return
        width  = int(params.get("width", 5))
        delay  = min(int(params.get("delay", 0)), HIRES_HAAS_MAX_MS)
        mode   = params.get("mode", "off")
        if mode == "off":
            self._set(self.ph_stereo, "stereo", 1.0)
            return
        # width → stereo plugin (0..1.0, neutral = 1.0)
        stereo_val = max(0.0, min(1.0, width / 100.0))
        # Jeśli width jest mała wartość (jak w presets 5/10/12/15), traktujemy
        # jako % → stereo 0.05..0.15 (subtelne poszerzenie)
        if width <= 20:
            stereo_val = width / 100.0
        self._set(self.ph_stereo, "stereo", stereo_val)

    # ── Helper ─────────────────────────────────────────────────────────────
    @staticmethod
    def _set(el, prop, val):
        if el is None:
            return
        try:
            el.set_property(prop, float(val) if isinstance(val, (int, float)) else val)
        except Exception as e:
            print(f"[FX] {el.get_name()}.{prop}={val}: {e}")


# ============================================================================
# DynamicEQProcessor — spectrum-driven z fixem + tryb BANDS
# ============================================================================
class DynamicEQProcessor:
    """
    Dynamic EQ — dwa tryby zgodnie z wyborem użytkownika:

    AUTO  (SmartEQ spectrum-driven, FIXED):
      • Bug z carbONmp: chunk = len(spec)//10 gubił resztę gdy len(spec) nie
        dzieliło się przez 10; ponadto ostatnie pasma dostawały mniej próbek.
      • Bug 2: tgt=[0.65]*10 był zbyt agresywny (kompresja loudness a nie EQ).
      • Fix: poprawny podział log-scale 128 band → 10 band EQ (każde pasmo EQ
        dostaje właściwy zakres magnitud). Target 0.4 (umiarkowany). Smoothing
        0.95 (było 0.9 — powodowało pumping). Korekcja max ±6 dB (było ±12).

    BANDS (klasyczny dynamic EQ):
      • Wykorzystuje MultibandLimiter POST_EQ — 5 kompresorów na pasmach
        SUB/BASS/LO-MID/HI-MID/AIR z sidechainem.
      • Threshold / ratio per band ustawiane przez panel.
    """

    # Mapowanie 128 pasm spectrum (0..22050 Hz przy 44.1 kHz) → 10 pasm EQ
    # EQ pasma: 32, 64, 125, 250, 500, 1k, 2k, 4k, 8k, 16k
    # Spectrum pasma są liniowe w Hz — używamy log-mapping.
    _SPEC_BANDS = 128
    _EQ_BAND_EDGES_HZ = [22, 45, 90, 177, 354, 707, 1414, 2828, 5657, 11314, 22050]

    def __init__(self, fx_chain: FXChain):
        self.fx = fx_chain
        self.mode = "OFF"  # OFF | AUTO | BANDS
        self.depth = 0.5
        self.smoothing = 0.95
        self.target = 0.4
        self.base = [0.0] * 10       # bazowe wartości EQ od użytkownika
        self.curr = [0.0] * 10       # wygładzony aktualny output
        self._lock = threading.Lock()
        # Dla trybu BANDS — referencja do limitera POST_EQ ustawiana przez router
        self.bands_limiter = None  # type: MultibandLimiter | None

    def set_mode(self, mode: str):
        if mode not in ("OFF", "AUTO", "BANDS"):
            mode = "OFF"
        self.mode = mode
        # Przy wyłączeniu AUTO — przywróć bazowe wartości EQ
        if mode != "AUTO":
            with self._lock:
                for i, v in enumerate(self.base):
                    self.curr[i] = v
                    self.fx.set_eq_band(i, v)
        # Przy wyłączeniu BANDS — wyłącz POST_EQ limiter
        if mode != "BANDS" and self.bands_limiter is not None:
            self.bands_limiter.set_enabled(False)
        elif mode == "BANDS" and self.bands_limiter is not None:
            self.bands_limiter.set_enabled(True)

    def set_base_band(self, i: int, val: float):
        """Użytkownik zmienił suwak EQ — aktualizuj bazę."""
        with self._lock:
            self.base[i] = float(val)
            if self.mode != "AUTO":
                self.curr[i] = float(val)
                self.fx.set_eq_band(i, float(val))

    def set_all_base(self, vals: list):
        with self._lock:
            self.base = [float(v) for v in vals[:10]] + [0.0] * max(0, 10 - len(vals))
            if self.mode != "AUTO":
                self.curr = list(self.base)
                for i, v in enumerate(self.base):
                    self.fx.set_eq_band(i, v)

    def set_bands_limiter(self, mbl):
        """Router przekazuje referencję do limitera POST_EQ dla trybu BANDS."""
        self.bands_limiter = mbl
        if self.mode == "BANDS" and mbl is not None:
            mbl.set_enabled(True)

    def set_band_threshold(self, i: int, thr: float):
        """Tryb BANDS — próg kompresji na pasmie i."""
        if self.bands_limiter is not None:
            self.bands_limiter.set_band_threshold(i, thr)

    def set_band_ratio(self, i: int, ratio: float):
        if self.bands_limiter is not None:
            self.bands_limiter.set_band_ratio(i, ratio)

    # ── Spectrum callback (tryb AUTO) ─────────────────────────────────────
    def on_spectrum_message(self, structure):
        """Wywoływane z Gst bus gdy nadejdzie wiadomość spectrum.
        structure — GstStructure z polami 'magnitude' (lista 128 wartości)."""
        if self.mode != "AUTO":
            return
        try:
            mags = structure.get_value("magnitude")
            if mags is None:
                return
            # mags to GValueArray w starym API lub lista w nowym — konwersja
            if hasattr(mags, "__iter__"):
                mags = list(mags)
            else:
                # GstValueList — użyj nth
                n = mags.nth if hasattr(mags, "nth") else None
                if n is None:
                    return
                mags = [mags.nth(i) for i in range(self._SPEC_BANDS)]
        except Exception as e:
            print("[DynEQ] spectrum parse error:", e)
            return
        if not mags:
            return
        # Wywołaj process w wątku głównym — spectrum messages przychodzą z bus,
        # który jest już main-thread, ale na wszelki wypadek thread-safe.
        self._process_spectrum(mags)

    def _process_spectrum(self, mags: list):
        """Core: spectrum magnitudes → korekcje EQ per band."""
        with self._lock:
            # Magnitudes są w dB (-80..0). Konwersja na liniową energię.
            # Mapowanie log-scale: każde pasmo EQ dostaje magnitudy z zakresu
            # [_EQ_BAND_EDGES_HZ[i], _EQ_BAND_EDGES_HZ[i+1]].
            sample_rate = 44100  # domyślne; spectrum nie raportuje SR
            nyq = sample_rate / 2
            n_bands = len(mags)
            bin_hz = nyq / n_bands
            # Skoryguj dla hi-res — jeśli spectrum wie o SR, użyj go.
            # (spectrum nie podaje SR w wiadomości — zakładamy maks. 96 kHz)
            try:
                sr_field = None
            except Exception:
                pass

            for i in range(10):
                f_lo = self._EQ_BAND_EDGES_HZ[i]
                f_hi = self._EQ_BAND_EDGES_HZ[i + 1]
                bin_lo = max(0, int(f_lo / nyq * n_bands))
                bin_hi = min(n_bands - 1, int(f_hi / nyq * n_bands))
                if bin_hi <= bin_lo:
                    bin_hi = bin_lo + 1
                chunk = mags[bin_lo:bin_hi]
                if not chunk:
                    continue
                # Średnia energia (dB → linear → mean → dB)
                lin = [10 ** (m / 20.0) for m in chunk]
                ea = sum(lin) / len(lin)
                ea_db = 20 * math.log10(max(1e-9, ea))
                # Normalizuj: -80..0 dB → 0..1
                ea_norm = max(0.0, min(1.0, (ea_db + 80) / 80))
                # Korekcja: różnica względem targetu × depth
                # (positive = band za cichy → boost; negative = za głośny → cut)
                target = self.target
                # Limit korekcji do ±6 dB (było ±12 — zbyt agresywne)
                dc = max(-6.0, min(6.0, (target - ea_norm) * 12.0 * self.depth))
                des = max(-12.0, min(12.0, self.base[i] + dc))
                # Wygładzenie (smoothing 0.95 — zapobiega pumping)
                self.curr[i] = self.curr[i] * self.smoothing + des * (1 - self.smoothing)
                # Aplikuj do elementu EQ
                self.fx.set_eq_band(i, self.curr[i])


# ============================================================================
# MultibandLimiter — 5-band z tee→queues→filters→mixer
# ============================================================================
class BandLimiterNode:
    """Jedno pasmo limitera — audioconvert → capsfilter(F32LE) → filtr
    → audiodynamic(limiter) → audioconvert. Samowystarczalny, wstrzykiwany
    między tee a audiomixer przez MultibandLimiter."""

    def __init__(self, pipeline, name: str, band_cfg: dict):
        self.pipeline = pipeline
        self.name = name
        self.band_cfg = band_cfg
        self.enabled = True

        n = name
        self._conv_in  = mkgst("audioconvert", f"{n}_conv_in")
        self._caps_f32 = mkgst("capsfilter",   f"{n}_capsf32")
        if self._caps_f32:
            try:
                self._caps_f32.set_property("caps",
                    Gst.Caps.from_string("audio/x-raw,format=F32LE"))
            except Exception as e:
                print(f"[MBL] {n} caps: {e}")

        # Filtr pasmowy
        self._band_hi = None
        self._filter = self._build_filter(band_cfg, n)

        self._limiter = mkgst("audiodynamic", f"{n}_limiter", {
            "characteristics": "hard-knee", "mode": "compressor",
            "threshold": float(band_cfg["threshold"]),
            "ratio":     float(band_cfg["ratio"]),
        })
        self._conv_out = mkgst("audioconvert", f"{n}_conv_out")

        for el in [self._conv_in, self._caps_f32, self._band_hi, self._filter,
                   self._limiter, self._conv_out]:
            if el is not None:
                pipeline.add(el)
        self._link_internal()

    def _build_filter(self, cfg, prefix):
        ftype = cfg["filter"]
        if ftype == "lo":
            return mkgst("audiocheblimit", f"{prefix}_filt", {
                "mode": "low-pass", "cutoff": float(cfg["f_hi"]), "poles": 4,
            })
        elif ftype == "hi":
            return mkgst("audiocheblimit", f"{prefix}_filt", {
                "mode": "high-pass", "cutoff": float(cfg["f_lo"]), "poles": 4,
            })
        else:  # band — hi-pass + lo-pass kaskadowo
            self._band_hi = mkgst("audiocheblimit", f"{prefix}_filt_hi", {
                "mode": "high-pass", "cutoff": float(cfg["f_lo"]), "poles": 4,
            })
            lo = mkgst("audiocheblimit", f"{prefix}_filt_lo", {
                "mode": "low-pass",  "cutoff": float(cfg["f_hi"]), "poles": 4,
            })
            return lo

    def _link_internal(self):
        chain = [self._conv_in, self._caps_f32]
        if self._band_hi is not None:
            chain.append(self._band_hi)
        chain += [self._filter, self._limiter, self._conv_out]
        for a, b in zip(chain, chain[1:]):
            _lnk(a, b)

    def get_entry(self):
        return self._conv_in

    def get_exit(self):
        return self._conv_out

    def set_threshold(self, thr: float):
        self.band_cfg["threshold"] = float(thr)
        if self._limiter and self.enabled:
            try: self._limiter.set_property("threshold", float(thr))
            except Exception: pass

    def set_ratio(self, ratio: float):
        self.band_cfg["ratio"] = float(ratio)
        if self._limiter and self.enabled:
            try: self._limiter.set_property("ratio", float(ratio))
            except Exception: pass

    def set_enabled(self, en: bool):
        self.enabled = en
        if not en:
            # Bypass — ratio=1.0, threshold=1.0 (przepuszcza sygnał bez kompresji)
            if self._limiter:
                try: self._limiter.set_property("ratio", 1.0)
                except Exception: pass
                try: self._limiter.set_property("threshold", 1.0)
                except Exception: pass
        else:
            # Przywróć wartości
            if self._limiter:
                try: self._limiter.set_property("ratio", float(self.band_cfg["ratio"]))
                except Exception: pass
                try: self._limiter.set_property("threshold", float(self.band_cfg["threshold"]))
                except Exception: pass


class MultibandLimiter:
    """5-band limiter — zarządca N węzłów BandLimiterNode z tee→queues→mixer.

    Topologia:
      upstream → tee → queue_i → BandNode_i → mixer → caps_out → conv → downstream
                  (×5)

    Wstrzykiwany między dwa elementy pipeline. Bypass = ratio 1.0 / threshold 1.0
    we wszystkich węzłach (sygnał płynie przez filtry ale bez kompresji).
    """

    def __init__(self, pipeline, name_prefix: str, bands_cfg: list):
        self.pipeline = pipeline
        self.prefix = name_prefix
        self.enabled = False
        self._injected = False
        self._upstream = None
        self._downstream = None

        self._tee   = mkgst("tee",        f"{name_prefix}_tee")
        self._mixer = mkgst("audiomixer", f"{name_prefix}_mix")
        if self._mixer:
            try: self._mixer.set_property("output-buffer-duration", 10_000_000)
            except Exception: pass
        self._caps_out = mkgst("capsfilter", f"{name_prefix}_caps_out")
        if self._caps_out:
            try:
                self._caps_out.set_property("caps",
                    Gst.Caps.from_string("audio/x-raw,format=F32LE"))
            except Exception: pass
        self._conv = mkgst("audioconvert", f"{name_prefix}_conv")
        for el in [self._tee, self._mixer, self._caps_out, self._conv]:
            if el is not None:
                pipeline.add(el)

        # Kolejki między tee a węzłami
        self._queues = []
        for i in range(len(bands_cfg)):
            q = mkgst("queue", f"{name_prefix}_q{i}",
                      {"max-size-buffers": 4, "max-size-time": 0, "max-size-bytes": 0})
            if q is not None:
                pipeline.add(q)
            self._queues.append(q)

        # Węzły pasm
        self.nodes = []
        for i, cfg in enumerate(bands_cfg):
            node = BandLimiterNode(pipeline, f"{name_prefix}_b{i}", cfg)
            self.nodes.append(node)

        # Link wewnętrzny: tee → queue_i → node_i → mixer
        for q, node in zip(self._queues, self.nodes):
            _lnk(self._tee, q)
            if q is not None and node.get_entry() is not None:
                _lnk(q, node.get_entry())
            if node.get_exit() is not None and self._mixer is not None:
                _lnk(node.get_exit(), self._mixer)
        # mixer → caps_out → conv
        if self._mixer and self._caps_out and self._conv:
            _lnk(self._mixer, self._caps_out)
            _lnk(self._caps_out, self._conv)

    def inject(self, upstream_el, downstream_el):
        """Wstrzykuje cały limiter między dwa elementy."""
        if self._injected:
            self.eject()
        if upstream_el is None or downstream_el is None:
            return False
        self._upstream = upstream_el
        self._downstream = downstream_el
        # Odepnij istniejące połączenie upstream → downstream
        _unlink_full(upstream_el, downstream_el)
        # Link: upstream → tee ... conv → downstream
        ok1 = _lnk(upstream_el, self._tee)
        ok2 = _lnk(self._conv, downstream_el)
        # Sync state
        sync_els = ([self._tee] + self._queues
                   + [n._conv_in for n in self.nodes]
                   + [n._filter for n in self.nodes]
                   + [n._limiter for n in self.nodes]
                   + [n._conv_out for n in self.nodes]
                   + [self._mixer, self._caps_out, self._conv])
        for el in sync_els:
            if el is not None:
                try: el.sync_state_with_parent()
                except Exception: pass
        self._injected = True
        print(f"[MBL:{self.prefix}] injected: {upstream_el.get_name()} → [limiter] → {downstream_el.get_name()}")
        return ok1 and ok2

    def eject(self):
        if not self._injected:
            return
        # Stop elementów
        stop_els = ([self._tee] + self._queues
                    + [n._conv_in for n in self.nodes]
                    + [n._filter for n in self.nodes]
                    + [n._limiter for n in self.nodes]
                    + [n._conv_out for n in self.nodes]
                    + [self._mixer, self._caps_out, self._conv])
        for el in stop_els:
            if el is not None:
                try: el.set_state(Gst.State.NULL)
                except Exception: pass
        # Odepnij
        if self._upstream and self._tee:
            _unlink_full(self._upstream, self._tee)
        if self._conv and self._downstream:
            _unlink_full(self._conv, self._downstream)
        # Przywróć bezpośrednie połączenie
        _lnk(self._upstream, self._downstream)
        self._injected = False
        self._upstream = None
        self._downstream = None

    def set_enabled(self, en: bool):
        self.enabled = en
        for node in self.nodes:
            node.set_enabled(en)

    def set_band_threshold(self, i: int, thr: float):
        if 0 <= i < len(self.nodes):
            self.nodes[i].set_threshold(thr)

    def set_band_ratio(self, i: int, ratio: float):
        if 0 <= i < len(self.nodes):
            self.nodes[i].set_ratio(ratio)

    def apply_state(self, point_state: dict):
        """Aplikuje {'enabled': bool, 'bands': [{'thr','ratio'}, ...]}."""
        en = bool(point_state.get("enabled", False))
        self.set_enabled(en)
        for i, b in enumerate((point_state.get("bands") or [])[:len(self.nodes)]):
            if "thr" in b:
                self.set_band_threshold(i, b["thr"])
            if "ratio" in b:
                self.set_band_ratio(i, b["ratio"])

    # ── AUTO PROTECT — automatyczna ochrona przed przesterem ──────────────
    # Limitery same monitorują poziomy pasm przez istniejące elementy `level`
    # (post-messages=True, interval=50ms) i dynamicznie dostosowują threshold.
    # Ratio capped at SAFE_RATIO per band (delikatniej dla SUB, mocniej dla AIR).
    # Domyślnie ON w trybie hi-res — chroni użytkownika który "nie wie co robi".

    AUTO_SAFE_RATIO = (4.0, 3.5, 3.0, 3.0, 3.5)  # SUB / BASS / LO-MID / HI-MID / AIR
    AUTO_TARGET_HEADROOM_DB = 1.0   # utrzymuj peak 1 dB poniżej threshold
    AUTO_MIN_THR = 0.30             # nie schodź poniżej (otherwise over-compression)
    AUTO_MAX_THR = 0.98             # powyżej = efektywnie bypass (sygnał cichy)
    AUTO_ALPHA = 0.10               # smoothing (0=static, 1=instant)
    AUTO_RELEASE_FRAMES = 20        # ~1s przy 50ms interval — po tym czasie relax

    def set_auto_protect(self, en: bool):
        """Włącza/wyłącza automatyczną ochronę. Gdy włączone:
           • wymusza enabled=True na tym MBL
           • ustawia SAFE_RATIO per band
           • threshold będzie dynamicznie dostosowywany przez handle_level_message
        """
        self._auto_protect = en
        self._auto_peak_db = [-80.0] * len(self.nodes)
        self._auto_below_frames = [0] * len(self.nodes)
        if en:
            self.set_enabled(True)
            for i, ratio in enumerate(self.AUTO_SAFE_RATIO):
                if i < len(self.nodes):
                    self.set_band_ratio(i, ratio)
            print(f"[MBL:{self.prefix}] AUTO PROTECT ON — threshold auto-track (1dB headroom, ratio ≤ {max(self.AUTO_SAFE_RATIO)})")

    def handle_level_message(self, band_i: int, peak_db: float, rms_db: float):
        """Wywoływane przez FXController gdy nadejdzie wiadomość `level` z tego MBL.
        peak_db / rms_db — wartości w dBFS (-∞..0). Gdy AUTO PROTECT włączony,
        dynamicznie dostosowuje threshold tego pasma aby utrzymać headroom.

        Algorytm z hysteresis:
          • smoothed > -18 dB (sygnał aktywny): threshold = peak - 1dB headroom
          • smoothed ≤ -18 dB przez < RELEASE_FRAMES klatek: HOLD obecny threshold
            (nie ruszaj — zapobiega szybkim on/off cyklom)
          • smoothed ≤ -18 dB przez ≥ RELEASE_FRAMES klatek (~1s): RELAX do MAX
            (efektywnie bypass — sygnał cichy, nie potrzebuje limitowania)
        """
        if not getattr(self, "_auto_protect", False):
            return
        if band_i >= len(self.nodes):
            return
        # Smooth peak (wygładzanie — zapobiega pompowaniu na szybkich transientach)
        prev = self._auto_peak_db[band_i]
        smoothed = prev * (1 - self.AUTO_ALPHA) + peak_db * self.AUTO_ALPHA
        self._auto_peak_db[band_i] = smoothed

        if smoothed > -18.0:
            # Aktywny sygnał — track z headroom
            target_peak_db = smoothed - self.AUTO_TARGET_HEADROOM_DB
            target_amp = 10 ** (target_peak_db / 20.0)
            target_thr = max(self.AUTO_MIN_THR, min(self.AUTO_MAX_THR, target_amp))
            self._auto_below_frames[band_i] = 0
        else:
            # Cichy sygnał — hysteresis
            self._auto_below_frames[band_i] += 1
            if self._auto_below_frames[band_i] >= self.AUTO_RELEASE_FRAMES:
                # Po ~1s ciszy — relax do bypass
                target_thr = self.AUTO_MAX_THR
            else:
                # Hold — nie zmieniaj threshold przez pierwsze ~1s ciszy
                return

        # Aplikuj threshold (tylko gdy się zmienił o >0.005 — oszczędność wywołań)
        node = self.nodes[band_i]
        cur_thr = float(node.band_cfg.get("threshold", 0.0))
        if abs(target_thr - cur_thr) > 0.005:
            self.set_band_threshold(band_i, target_thr)


# ============================================================================
# LimiterRouter — zarządza 3 punktami wstrzyknięcia
# ============================================================================
class LimiterRouter:
    """Rejestruje 3 limity MBL (INPUT, POST_EQ, POST_FX) i aplikuje stan sceny."""

    POINTS = ("INPUT", "POST_EQ", "POST_FX")

    def __init__(self):
        self.points = {}  # pid -> (mbl, prev_el, next_el)

    def register(self, pid: str, mbl: MultibandLimiter, prev_el, next_el):
        self.points[pid] = (mbl, prev_el, next_el)

    def apply(self, limiter_state: dict):
        """limiter_state = {'INPUT': {...}, 'POST_EQ': {...}, 'POST_FX': {...}}."""
        for pid, st in (limiter_state or {}).items():
            if pid not in self.points:
                continue
            mbl, _, _ = self.points[pid]
            mbl.apply_state(st)

    def set_auto_protect_all(self, en: bool):
        """Włącza/wyłącza AUTO PROTECT na wszystkich 3 punktach limitera."""
        for pid in self.POINTS:
            if pid in self.points:
                mbl, _, _ = self.points[pid]
                mbl.set_auto_protect(en)

    def get_level_element_names(self) -> dict:
        """Zwraca mapowanie element_name → (mbl, band_i) dla wszystkich
        elementów `level` we wszystkich punktach. Używane przez FXController
        do dispatchu wiadomości `level` z bus."""
        dispatch = {}
        for pid in self.POINTS:
            if pid not in self.points:
                continue
            mbl, _, _ = self.points[pid]
            for i, node in enumerate(mbl.nodes):
                if node._level is not None:
                    dispatch[node._level.get_name()] = (mbl, i)
        return dispatch


# ============================================================================
# SceneManager — save / load / export / import
# ============================================================================
class SceneManager:
    """Zapisuje i wczytuje sceny. Wbudowane sceny są read-only i zawsze
    dostępne; użytkownik może je nadpisać lub dodać własne (zapisywane do
    SCENE_FILE). Eksport/import do/z pliku JSON."""

    def __init__(self, fx_state: FXState, fx_chain: FXChain,
                 dyn_eq: DynamicEQProcessor, router: LimiterRouter,
                 app_ref=None):
        self.state = fx_state
        self.fx = fx_chain
        self.dyn_eq = dyn_eq
        self.router = router
        self.app = app_ref
        self.scenes = {}
        self.current = None
        self._load()

    def _load(self):
        self.scenes = deepcopy(BUILTIN_SCENES_HIRES)
        try:
            user = json.loads(SCENE_FILE.read_text(encoding="utf-8"))
            # User scenes mogą nadpisać builtin (np. zmodyfikowany "🎵 Music Hi-Fi")
            self.scenes.update(user)
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            pass
        except Exception as e:
            print(f"[Scenes] load error: {e}")

    def _save_user(self):
        """Zapisuje tylko sceny różne od builtin (oszczędność miejsca)."""
        user = {n: s for n, s in self.scenes.items()
                if n not in BUILTIN_SCENES_HIRES or s != BUILTIN_SCENES_HIRES.get(n)}
        try:
            SCENE_FILE.parent.mkdir(parents=True, exist_ok=True)
            SCENE_FILE.write_text(json.dumps(user, indent=2, ensure_ascii=False),
                                  encoding="utf-8")
        except Exception as e:
            print(f"[Scenes] save error: {e}")

    def list_scenes(self) -> list:
        return sorted(self.scenes.keys())

    def list_builtin(self) -> list:
        return sorted(BUILTIN_SCENES_HIRES.keys())

    def list_user(self) -> list:
        return sorted(n for n in self.scenes if n not in BUILTIN_SCENES_HIRES)

    def get(self, name: str) -> dict | None:
        return self.scenes.get(name)

    def is_builtin(self, name: str) -> bool:
        return name in BUILTIN_SCENES_HIRES

    # ── Snapshot ────────────────────────────────────────────────────────────
    def snapshot(self, name: str, icon: str = "✨", desc: str = "") -> dict:
        """Zapisuje aktualny stan jako scenę o podanej nazwie."""
        prev = self.scenes.get(name, {})
        s = {
            "meta": {
                "icon": icon,
                "desc": desc or (prev.get("meta", {}).get("desc", "")),
                "created": prev.get("meta", {}).get("created",
                                                    datetime.now().isoformat()),
                "modified": datetime.now().isoformat(),
            },
            "volume": getattr(self.app, "vol", None) and
                      int(self.app.vol.get_value()) if self.app and hasattr(self.app, "vol") else 80,
            "chain":       deepcopy(self.state.chain),
            "eq":          deepcopy(self.state.eq),
            "eq_dynamic":  deepcopy(self.state.eq_dynamic),
            "tape":        deepcopy(self.state.tape),
            "spatial":     deepcopy(self.state.spatial),
            "phantom":     deepcopy(self.state.phantom),
            "limiter":     deepcopy(self.state.limiter),
        }
        # Hi-res fix przed zapisem (sanity)
        s = _hires_fix_scene(s)
        self.scenes[name] = s
        self._save_user()
        print(f"[Scenes] zapisano: {name!r}")
        return s

    # ── Apply ───────────────────────────────────────────────────────────────
    def apply(self, name: str) -> bool:
        s = self.scenes.get(name)
        if not s:
            print(f"[Scenes] brak sceny: {name!r}")
            return False
        # Wczytaj stan
        self.state.from_dict(s)
        # Aplikuj do GStreamer (jeśli pipeline istnieje)
        self.fx.set_tape(self.state.tape)
        self.fx.set_eq_all(self.state.eq.get("bands", [0] * 10))
        self.fx.set_spatial(self.state.spatial)
        self.fx.set_phantom(self.state.phantom)
        # Dynamic EQ — tryb zapisany w scenie
        dyn = self.state.eq_dynamic
        self.dyn_eq.set_mode(dyn.get("mode", "OFF"))
        if dyn.get("mode") == "AUTO":
            self.dyn_eq.depth = float(dyn.get("depth", 0.5))
            self.dyn_eq.smoothing = float(dyn.get("smoothing", 0.95))
            self.dyn_eq.target = float(dyn.get("target", 0.4))
            self.dyn_eq.set_all_base(self.state.eq.get("bands", [0] * 10))
        elif dyn.get("mode") == "BANDS":
            # Ustaw threshold/ratio per band z POST_EQ limitera
            post_eq = self.state.limiter.get("POST_EQ", {})
            for i, b in enumerate((post_eq.get("bands") or [])[:5]):
                self.dyn_eq.set_band_threshold(i, b.get("thr", 0.75))
                self.dyn_eq.set_band_ratio(i, b.get("ratio", 2.5))
        # Limiter — 3 punkty
        self.router.apply(self.state.limiter)
        # AUTO PROTECT — aplikuj flagę ze sceny (default ON)
        self.router.set_auto_protect_all(getattr(self.state, "limiter_auto_protect", True))
        # Volume
        if self.app and hasattr(self.app, "vol") and "volume" in s:
            try:
                self.app.vol.set_value(int(s["volume"]))
            except Exception:
                pass
        # Jeśli app ma metodę set_volume_player, wywołaj (zgodnie z hearthis_player)
        if self.app and hasattr(self.app, "_on_volume_apply_scene"):
            try: self.app._on_volume_apply_scene(int(s.get("volume", 80)))
            except Exception: pass
        self.current = name
        print(f"[Scenes] zastosowano: {name!r}")
        return True

    def delete(self, name: str) -> bool:
        if name in BUILTIN_SCENES_HIRES:
            print(f"[Scenes] nie można usunąć sceny wbudowanej: {name!r}")
            return False
        if name in self.scenes:
            del self.scenes[name]
            self._save_user()
            if self.current == name:
                self.current = None
            return True
        return False

    # ── Export / Import ────────────────────────────────────────────────────
    def export_scene(self, name: str, filepath: str | Path) -> bool:
        s = self.scenes.get(name)
        if not s:
            return False
        try:
            Path(filepath).write_text(
                json.dumps({"scene_name": name, "exported_at": datetime.now().isoformat(),
                            "scene": s}, indent=2, ensure_ascii=False),
                encoding="utf-8")
            print(f"[Scenes] wyeksportowano {name!r} → {filepath}")
            return True
        except Exception as e:
            print(f"[Scenes] export error: {e}")
            return False

    def import_scene(self, filepath: str | Path, new_name: str | None = None) -> str | None:
        """Wczytuje scenę z pliku JSON. Zwraca nazwę pod jaką zapisano."""
        try:
            data = json.loads(Path(filepath).read_text(encoding="utf-8"))
        except Exception as e:
            print(f"[Scenes] import read error: {e}")
            return None
        # Format 1: {"scene_name": "...", "scene": {...}} — nasz export
        # Format 2: bezpośrednio scene dict (np. z carbon_scenes.json)
        if isinstance(data, dict) and "scene" in data and isinstance(data["scene"], dict):
            name = new_name or data.get("scene_name") or " Imported"
            s = data["scene"]
        elif isinstance(data, dict) and ("tape" in data or "eq" in data or "limiter" in data):
            # Plik to bezpośrednio scena — użyj nazwy pliku jako nazwy sceny
            name = new_name or Path(filepath).stem
            s = data
        else:
            print("[Scenes] import: nierozpoznany format JSON")
            return None
        # Hi-res fix przy imporcie
        s = _hires_fix_scene(s)
        self.scenes[name] = s
        self._save_user()
        print(f"[Scenes] zaimportowano: {name!r}")
        return name


# ============================================================================
# FXPanel — GTK4 widget z zakładkami (Gtk.Notebook w Gtk.Revealer)
# ============================================================================
class FXPanel(Gtk.Box):
    """Panel FX z zakładkami:
       1. Sceny (lista + apply/save/export/import/delete)
       2. Tape (DRIVE/WARMTH/COMP + ACTIVE + Safe)
       3. EQ (10 suwaków + preset + tryb dynamiczny OFF/AUTO/BANDS)
       4. Spatial (WIDTH/DELAY/SAT + ENABLE)
       5. Phantom (preset dropdown + WIDTH/DELAY/BLEND)
       6. Limiter (3 sekcje: INPUT/POST_EQ/POST_FX — 5 band × thr/ratio)
       7. Signal Chain (gate/compressor/expander/hipass)
    """

    CSS = """
    .fx-panel { background: #1a1a1e; color: #eee; padding: 8px; }
    .fx-tab-label { font-weight: bold; font-size: 11px; }
    .fx-section { background: #232328; border-radius: 6px; padding: 8px; margin: 4px; }
    .fx-band-label { font-size: 10px; color: #888; }
    .fx-scene-active { background: #2a4a2a; }
    button.fx-toggle-active { background: #005500; color: #fff; }
    """

    def __init__(self, fx_state: FXState, fx_chain: FXChain,
                 dyn_eq: DynamicEQProcessor, scene_mgr: SceneManager,
                 app_ref=None):
        super().__init__(orientation=Gtk.Orientation.VERTICAL)
        self.state = fx_state
        self.fx = fx_chain
        self.dyn_eq = dyn_eq
        self.scenes = scene_mgr
        self.app = app_ref
        self._sync_lock = False  # blokuje sygnały gdy programowo aktualizujemy UI

        # CSS
        css = Gtk.CssProvider()
        css.load_from_data(self.CSS.encode("utf-8"))
        Gtk.StyleContext.add_provider_for_display(
            Gdk.Display.get_default(), css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        self.add_css_class("fx-panel")
        self.set_size_request(-1, 280)

        # Scene bar (górny pasek)
        self._build_scene_bar()

        # Notebook z zakładkami
        self.notebook = Gtk.Notebook()
        self.notebook.set_hexpand(True)
        self.notebook.set_vexpand(True)
        self.notebook.set_scrollable(True)
        self.append(self.notebook)

        # Zakładki
        self._tab_tape()
        self._tab_eq()
        self._tab_spatial()
        self._tab_phantom()
        self._tab_limiter()
        self._tab_chain()
        self._tab_scenes_detail()

        # Aplikuj stan początkowy
        self.sync_from_state()

    # ── Scene bar ──────────────────────────────────────────────────────────
    def _build_scene_bar(self):
        bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        bar.set_margin_start(8); bar.set_margin_end(8)
        bar.set_margin_top(4);   bar.set_margin_bottom(4)

        bar.append(Gtk.Label(label="Scena:", css_classes=["fx-tab-label"]))
        self.scene_dd = Gtk.DropDown.new_from_strings(self.scenes.list_scenes())
        self.scene_dd.set_hexpand(True)
        bar.append(self.scene_dd)

        self.btn_apply = Gtk.Button(label="Zastosuj")
        self.btn_apply.connect("clicked", self._on_scene_apply)
        bar.append(self.btn_apply)

        self.btn_save = Gtk.Button(label="Zapisz jako…")
        self.btn_save.connect("clicked", self._on_scene_save)
        bar.append(self.btn_save)

        self.btn_export = Gtk.Button(label="Eksportuj…")
        self.btn_export.connect("clicked", self._on_scene_export)
        bar.append(self.btn_export)

        self.btn_import = Gtk.Button(label="Importuj…")
        self.btn_import.connect("clicked", self._on_scene_import)
        bar.append(self.btn_import)

        self.btn_delete = Gtk.Button(label="Usuń")
        self.btn_delete.connect("clicked", self._on_scene_delete)
        bar.append(self.btn_delete)

        self.scene_desc_lbl = Gtk.Label(label="", xalign=0,
                                        css_classes=["dim-label", "caption"])
        self.scene_desc_lbl.set_hexpand(True)
        bar.append(self.scene_desc_lbl)

        self.append(bar)

    # ── Tape tab ───────────────────────────────────────────────────────────
    def _tab_tape(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        box.set_margin_start(12); box.set_margin_end(12)
        box.set_margin_top(8);    box.set_margin_bottom(8)

        # Top row: ACTIVE + Safe
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        self.tape_active = Gtk.CheckButton(label="ACTIVE — Tape Saturation")
        self.tape_active.set_active(self.state.tape["active"])
        self.tape_active.connect("toggled", self._on_tape_active)
        row.append(self.tape_active)

        self.tape_safe = Gtk.CheckButton(label="🛡 Safe Mode (DRIVE≤40, WARMTH≤50, COMP≤30)")
        self.tape_safe.set_active(self.state.tape.get("safe_mode", True))
        self.tape_safe.connect("toggled", self._on_tape_safe)
        row.append(self.tape_safe)
        row.append(Gtk.Label(label="(hi-res domyślnie ON)", css_classes=["dim-label", "caption"]))
        box.append(row)

        # Dials — trzy suwaki. Zakresy 0-50 (hi-res — max 50% zamiast 100,
        # pełen zakres nie miał sensu i prowadził do przesterów).
        # Safe Limits nadal obowiązują: DRIVE≤40, WARMTH≤50, COMP≤30.
        grid = Gtk.Grid()
        grid.set_column_spacing(16)
        grid.set_row_spacing(6)
        self.tape_dials = {}
        for col, (key, mn, mx, df) in enumerate([
            ("DRIVE",  0, 50, self.state.tape["drive"]),
            ("WARMTH", 0, 50, self.state.tape["warmth"]),
            ("COMP",   0, 50, self.state.tape["comp"]),
        ]):
            lbl = Gtk.Label(label=key, css_classes=["fx-tab-label"])
            grid.attach(lbl, col, 0, 1, 1)
            scale = Gtk.Scale.new_with_range(Gtk.Orientation.VERTICAL, mn, mx, 1)
            scale.set_value(df)
            scale.set_vexpand(True)
            scale.set_size_request(40, 120)
            scale.connect("value-changed", self._on_tape_dial, key)
            grid.attach(scale, col, 1, 1, 1)
            val_lbl = Gtk.Label(label=str(df), css_classes=["fx-band-label"])
            scale.connect("value-changed",
                          lambda s, l=val_lbl: l.set_label(str(int(s.get_value()))))
            grid.attach(val_lbl, col, 2, 1, 1)
            self.tape_dials[key] = (scale, val_lbl)
        box.append(grid)
        self._add_tab(box, "Tape", "audio-input-microphone-symbolic")

    # ── EQ tab ─────────────────────────────────────────────────────────────
    def _tab_eq(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        box.set_margin_start(12); box.set_margin_end(12)
        box.set_margin_top(8);    box.set_margin_bottom(8)

        # Top row: preset + dynamic mode
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        row.append(Gtk.Label(label="Preset:", css_classes=["fx-tab-label"]))
        self.eq_preset_dd = Gtk.DropDown.new_from_strings(list(EQ_PRESETS.keys()))
        self.eq_preset_dd.set_selected(list(EQ_PRESETS.keys()).index(self.state.eq["preset"]))
        self.eq_preset_dd.connect("notify::selected", self._on_eq_preset)
        row.append(self.eq_preset_dd)
        row.append(Gtk.Separator.new(Gtk.Orientation.VERTICAL))

        row.append(Gtk.Label(label="Dynamic EQ:", css_classes=["fx-tab-label"]))
        self.dyn_mode_dd = Gtk.DropDown.new_from_strings(["OFF", "AUTO", "BANDS"])
        modes = ["OFF", "AUTO", "BANDS"]
        self.dyn_mode_dd.set_selected(modes.index(self.state.eq_dynamic["mode"]))
        self.dyn_mode_dd.connect("notify::selected", self._on_dyn_mode)
        row.append(self.dyn_mode_dd)
        box.append(row)

        # Dynamic params (gdy AUTO lub BANDS)
        drow = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        drow.append(Gtk.Label(label="Depth:", css_classes=["fx-band-label"]))
        self.dyn_depth = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 1, 0.05)
        self.dyn_depth.set_value(self.state.eq_dynamic["depth"])
        self.dyn_depth.set_hexpand(True)
        self.dyn_depth.connect("value-changed", self._on_dyn_depth)
        drow.append(self.dyn_depth)
        drow.append(Gtk.Label(label="Smooth:", css_classes=["fx-band-label"]))
        self.dyn_smooth = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0.5, 0.99, 0.01)
        self.dyn_smooth.set_value(self.state.eq_dynamic["smoothing"])
        self.dyn_smooth.set_hexpand(True)
        self.dyn_smooth.connect("value-changed", self._on_dyn_smooth)
        drow.append(self.dyn_smooth)
        drow.append(Gtk.Label(label="Target:", css_classes=["fx-band-label"]))
        self.dyn_target = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0.1, 0.8, 0.05)
        self.dyn_target.set_value(self.state.eq_dynamic["target"])
        self.dyn_target.set_hexpand(True)
        self.dyn_target.connect("value-changed", self._on_dyn_target)
        drow.append(self.dyn_target)
        box.append(drow)

        # EQ bands — 10 vertical sliders
        grid = Gtk.Grid()
        grid.set_column_spacing(6)
        grid.set_row_spacing(4)
        self.eq_sliders = []
        for i, freq in enumerate(EQ_BAND_FREQS):
            lbl = Gtk.Label(label=f"{freq//1000}k" if freq >= 1000 else str(freq),
                            css_classes=["fx-band-label"])
            grid.attach(lbl, i, 0, 1, 1)
            scale = Gtk.Scale.new_with_range(Gtk.Orientation.VERTICAL, -12, 12, 1)
            scale.set_value(self.state.eq["bands"][i])
            scale.set_inverted(True)
            scale.set_vexpand(True)
            scale.set_size_request(36, 130)
            scale.connect("value-changed", self._on_eq_band, i)
            grid.attach(scale, i, 1, 1, 1)
            val_lbl = Gtk.Label(label=f"{self.state.eq['bands'][i]:+d}",
                                css_classes=["fx-band-label"])
            scale.connect("value-changed",
                          lambda s, l=val_lbl: l.set_label(f"{int(s.get_value()):+d}"))
            grid.attach(val_lbl, i, 2, 1, 1)
            self.eq_sliders.append(scale)
        box.append(grid)
        self._add_tab(box, "EQ", "preferences-desktop-multimedia-symbolic")

    # ── Spatial tab ────────────────────────────────────────────────────────
    def _tab_spatial(self):
        """Spatial FX — ZAWSZE aktywne w pipeline (brak checkboxa ENABLE).
        Suwaki width=0 + delay=0 + sat=10 dają passthrough hi-res."""
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        box.set_margin_start(12); box.set_margin_end(12)
        box.set_margin_top(8);    box.set_margin_bottom(8)

        # Banner zamiast checkboxa
        banner = Gtk.Label(
            label=f"Spatial FX — zawsze aktywne w pipeline. "
                  f"Suwaki w pozycjach domyślnych (width=0, delay=0, sat=10) = passthrough. "
                  f"Haas max {HIRES_HAAS_MAX_MS}ms (hi-res limit).",
            xalign=0, css_classes=["dim-label", "caption"], wrap=True)
        box.append(banner)

        self.sp_sliders = {}
        # Zakresy halved (max 50% oryginału) — pełne zakresy prowadziły do przesterów.
        # delay: hard cap HIRES_HAAS_MAX_MS=15 wciąż obowiązuje w set_spatial, ale
        # suwak max=7ms (bezpieczny subtelny Haas).
        for key, mn, mx, df, lbl_txt in [
            ("width",      0, 30, self.state.spatial["width"],      "Stereo Width (0-1.5%)"),
            ("delay",      0, 7,  self.state.spatial["delay"],      "Haas Delay (ms)"),
            ("saturation", 10, 45, self.state.spatial["saturation"], "Sat Ratio (/10 = X:1, max 4.5)"),
        ]:
            r = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            r.append(Gtk.Label(label=lbl_txt, css_classes=["fx-band-label"]))
            s = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, mn, mx, 1)
            s.set_value(df)
            s.set_hexpand(True)
            s.connect("value-changed", self._on_sp_slider, key)
            r.append(s)
            v = Gtk.Label(label=str(df), css_classes=["fx-band-label"])
            s.connect("value-changed", lambda sc, l=v: l.set_label(str(int(sc.get_value()))))
            r.append(v)
            self.sp_sliders[key] = s
            box.append(r)
        self._add_tab(box, "Spatial", "audio-card-symbolic")

    # ── Phantom tab ────────────────────────────────────────────────────────
    def _tab_phantom(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        box.set_margin_start(12); box.set_margin_end(12)
        box.set_margin_top(8);    box.set_margin_bottom(8)

        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        self.ph_active = Gtk.CheckButton(label="ENABLE — Phantom Stereo")
        self.ph_active.set_active(self.state.phantom["active"])
        self.ph_active.connect("toggled", self._on_ph_active)
        row.append(self.ph_active)
        box.append(row)

        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        row.append(Gtk.Label(label="Preset:", css_classes=["fx-tab-label"]))
        self.ph_preset_dd = Gtk.DropDown.new_from_strings(list(PHANTOM_PRESETS.keys()))
        cur_preset = self.state.phantom.get("preset", "Off")
        if cur_preset in PHANTOM_PRESETS:
            self.ph_preset_dd.set_selected(list(PHANTOM_PRESETS.keys()).index(cur_preset))
        self.ph_preset_dd.connect("notify::selected", self._on_ph_preset)
        row.append(self.ph_preset_dd)
        box.append(row)

        self.ph_desc = Gtk.Label(label="", xalign=0, css_classes=["dim-label", "caption"])
        box.append(self.ph_desc)
        self._update_phantom_desc()

        self.ph_sliders = {}
        # Zakresy halved — max 50% oryginału (pełne zakresy nie miały sensu).
        for key, mn, mx, df, lbl_txt in [
            ("width",  0, 10, self.state.phantom["width"],  "Width (0-10%)"),
            ("delay",  0, 7,  self.state.phantom["delay"],  "Haas Delay (ms)"),
            ("blend",  0, 25, self.state.phantom["blend"],  "Crossfeed Blend (0-25%)"),
        ]:
            r = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            r.append(Gtk.Label(label=lbl_txt, css_classes=["fx-band-label"]))
            s = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, mn, mx, 1)
            s.set_value(df)
            s.set_hexpand(True)
            s.connect("value-changed", self._on_ph_slider, key)
            r.append(s)
            v = Gtk.Label(label=str(df), css_classes=["fx-band-label"])
            s.connect("value-changed", lambda sc, l=v: l.set_label(str(int(sc.get_value()))))
            r.append(v)
            self.ph_sliders[key] = s
            box.append(r)
        # Echo intensity — domyślnie 0 (hi-res bypass), max 0.5 (halved z 1.0)
        r = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        r.append(Gtk.Label(label="Echo intensity (hi-res default 0, max 0.5):",
                           css_classes=["fx-band-label"]))
        self.ph_echo = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 0.5, 0.025)
        self.ph_echo.set_value(float(self.state.phantom.get("echo_intensity", 0.0)))
        self.ph_echo.set_hexpand(True)
        self.ph_echo.connect("value-changed", self._on_ph_echo)
        r.append(self.ph_echo)
        box.append(r)
        self._add_tab(box, "Phantom", "audio-headphones-symbolic")

    # ── Limiter tab (3 punkty × 5 band × thr+ratio + AUTO PROTECT) ──────────
    def _tab_limiter(self):
        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        outer.set_margin_start(12); outer.set_margin_end(12)
        outer.set_margin_top(8);    outer.set_margin_bottom(8)
        outer.append(Gtk.Label(
            label="Multiband Limiter (5 pasm: SUB/BASS/LO-MID/HI-MID/AIR). "
                  "3 punkty wstrzyknięcia: INPUT, POST_EQ, POST_FX.",
            xalign=0, css_classes=["dim-label", "caption"]))

        # GLOBAL AUTO PROTECT — domyślnie ON
        ap_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
        ap_box.set_css_classes(["fx-section"])
        self.ap_toggle = Gtk.CheckButton(
            label="🛡 AUTO PROTECT — limitery same monitorują pasma i dostosowują threshold")
        self.ap_toggle.set_tooltip_text(
            "Gdy włączone:\n"
            "• Wszystkie 3 limiter points aktywne\n"
            "• Ratio capped per band: SUB 4:1, BASS 3.5:1, MID 3:1, AIR 3.5:1\n"
            "• Threshold auto-dostosowywany co 50ms (1 dB headroom poniżej peak)\n"
            "• Po ~1s ciszy — relaks do bypass (sygnał cichy)\n"
            "Chroni przed przesterem nawet gdy inne efekty są mocno wysterowane.\n"
            "Domyślnie ON — wyłącz tylko jeśli wiesz co robisz.")
        self.ap_toggle.set_active(getattr(self.state, "limiter_auto_protect", True))
        self.ap_toggle.connect("toggled", self._on_ap_toggle)
        ap_box.append(self.ap_toggle)
        ap_box.append(Gtk.Label(
            label="(domyślnie ON — hi-res safe)",
            css_classes=["dim-label", "caption"]))
        outer.append(ap_box)

        self.lim_widgets = {}  # pid → {enable, thr_scales[], ratio_scales[]}
        for pid in LimiterRouter.POINTS:
            outer.append(Gtk.Label(label=f"● {pid}", css_classes=["fx-tab-label"]))
            point_state = self.state.limiter.get(pid, {})
            en = Gtk.CheckButton(label=f"{pid} ENABLE")
            en.set_active(bool(point_state.get("enabled", False)))
            en.connect("toggled", self._on_lim_point_enable, pid)
            outer.append(en)

            grid = Gtk.Grid()
            grid.set_column_spacing(12)
            grid.set_row_spacing(4)
            # Header
            for col, band_cfg in enumerate(MBLIMIT_BANDS):
                grid.attach(Gtk.Label(label=band_cfg["name"],
                                      css_classes=["fx-band-label"]), col, 0, 1, 1)
            grid.attach(Gtk.Label(label="Thr", css_classes=["fx-band-label"]),
                        len(MBLIMIT_BANDS), 0, 1, 1)
            grid.attach(Gtk.Label(label="Ratio", css_classes=["fx-band-label"]),
                        len(MBLIMIT_BANDS) + 1, 0, 1, 1)
            # Per band
            for col, band_cfg in enumerate(MBLIMIT_BANDS):
                lbl = Gtk.Label(label=f"{band_cfg['name']}",
                                css_classes=["fx-band-label"])
                grid.attach(lbl, col, 1, 1, 1)
            # Threshold sliders
            thr_row = 2
            for col, band_cfg in enumerate(MBLIMIT_BANDS):
                thr_val = float(point_state.get("bands", [{}]*5)[col].get("thr",
                              band_cfg["threshold"]))
                s = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0.1, 1.0, 0.01)
                s.set_value(thr_val)
                s.set_hexpand(True)
                s.connect("value-changed", self._on_lim_band, pid, col, "thr")
                grid.attach(s, col, thr_row, 1, 1)
            # Ratio sliders — zakres 1.0-5.0 (halved z 1.0-10.0; powyżej 5:1 to
            # już hard limiting prowadzący do pompowania i przesterów).
            for col, band_cfg in enumerate(MBLIMIT_BANDS):
                rt_val = float(point_state.get("bands", [{}]*5)[col].get("ratio",
                              band_cfg["ratio"]))
                # Klamp wartości z sceny do nowego max 5.0
                rt_val = min(rt_val, 5.0)
                s = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 1.0, 5.0, 0.1)
                s.set_value(rt_val)
                s.set_hexpand(True)
                s.connect("value-changed", self._on_lim_band, pid, col, "ratio")
                grid.attach(s, col, thr_row + 1, 1, 1)
            outer.append(grid)
            # Save enable check + sliders
            self.lim_widgets[pid] = {"enable": en}
        self._add_tab(outer, "Limiter", "preferences-system-network-symbolic")

    # ── Signal chain tab (gate/compressor/expander/hipass) ────────────────
    def _tab_chain(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        box.set_margin_start(12); box.set_margin_end(12)
        box.set_margin_top(8);    box.set_margin_bottom(8)
        box.append(Gtk.Label(label="Signal Chain — opcjonalne moduły (gate, comp, expander, hi-pass). "
                                    "lo_pass pominięty (hi-res).",
                             xalign=0, css_classes=["dim-label", "caption"]))
        # Definicje modułów
        self._chain_defs = {
            "gate":       ("Gate",       [("threshold", 0.0, 1.0, 0.05), ("ratio", 1.0, 20.0, 5.0)]),
            "compressor": ("Compressor", [("threshold", 0.0, 1.0, 0.5),  ("ratio", 1.0, 20.0, 2.0)]),
            "expander":   ("Expander",   [("threshold", 0.0, 1.0, 0.3),  ("ratio", 1.0, 10.0, 1.5)]),
            "hi_pass":    ("Hi-Pass",    [("cutoff",    20.0, 2000.0, 80.0)]),
        }
        self.chain_widgets = {}
        for mid, (label, params) in self._chain_defs.items():
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
            en = Gtk.CheckButton(label=label)
            cur = self.state.chain.get(mid, {})
            en.set_active(bool(cur.get("enabled", False)))
            en.connect("toggled", self._on_chain_enable, mid)
            row.append(en)
            for pname, mn, mx, df in params:
                row.append(Gtk.Label(label=pname, css_classes=["fx-band-label"]))
                s = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, mn, mx, (mx-mn)/100)
                cur_val = cur.get("params", {}).get(pname, df)
                s.set_value(float(cur_val))
                s.set_hexpand(True)
                s.connect("value-changed", self._on_chain_param, mid, pname)
                row.append(s)
            box.append(row)
            self.chain_widgets[mid] = {"enable": en}
        self._add_tab(box, "Chain", "media-playlist-repeat-symbolic")

    # ── Scenes detail tab ──────────────────────────────────────────────────
    def _tab_scenes_detail(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        box.set_margin_start(12); box.set_margin_end(12)
        box.set_margin_top(8);    box.set_margin_bottom(8)
        box.append(Gtk.Label(label="Wbudowane sceny (read-only — hi-res fix):",
                             css_classes=["fx-tab-label"], xalign=0))
        self.scenes_listbox = Gtk.ListBox()
        self.scenes_listbox.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.scenes_listbox.set_hexpand(True)
        self.scenes_listbox.set_vexpand(True)
        for name in self.scenes.list_builtin():
            row = self._scene_row(name, builtin=True)
            self.scenes_listbox.append(row)
        box.append(Gtk.Label(label="Sceny użytkownika:", css_classes=["fx-tab-label"], xalign=0))
        self.user_listbox = Gtk.ListBox()
        self.user_listbox.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.user_listbox.set_hexpand(True)
        self.user_listbox.set_vexpand(True)
        for name in self.scenes.list_user():
            row = self._scene_row(name, builtin=False)
            self.user_listbox.append(row)
        box.append(self.user_listbox)
        self._add_tab(box, "Sceny", "document-open-symbolic")

    def _scene_row(self, name: str, builtin: bool) -> Gtk.ListBoxRow:
        row = Gtk.ListBoxRow()
        hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        s = self.scenes.get(name) or {}
        meta = s.get("meta", {})
        icon_lbl = Gtk.Label(label=meta.get("icon", "✨"))
        hbox.append(icon_lbl)
        name_lbl = Gtk.Label(label=name, xalign=0)
        hbox.append(name_lbl)
        desc_lbl = Gtk.Label(label=meta.get("desc", ""), xalign=0,
                             css_classes=["dim-label", "caption"])
        desc_lbl.set_hexpand(True)
        hbox.append(desc_lbl)
        tag = Gtk.Label(label="BUILTIN" if builtin else "USER",
                        css_classes=["fx-band-label"])
        hbox.append(tag)
        row.set_child(hbox)
        row.name = name
        return row

    # ── Helper: dodaj zakładkę ─────────────────────────────────────────────
    def _add_tab(self, widget, label_text, icon_name):
        lbl = Gtk.Label(label=label_text)
        self.notebook.append_page(widget, lbl)

    # ── Event handlers ─────────────────────────────────────────────────────
    def _on_tape_active(self, btn):
        if self._sync_lock: return
        self.state.tape["active"] = btn.get_active()
        self.fx.set_tape(self.state.tape)

    def _on_tape_safe(self, btn):
        if self._sync_lock: return
        self.state.tape["safe_mode"] = btn.get_active()
        # Klampuj obecne wartości
        for key in ("DRIVE", "WARMTH", "COMP"):
            if key in self.tape_dials:
                scale, _ = self.tape_dials[key]
                cur = int(scale.get_value())
                if btn.get_active():
                    lim = SAFE_LIMITS[key]
                    if cur > lim:
                        scale.set_value(lim)
        self.fx.set_tape(self.state.tape)

    def _on_tape_dial(self, scale, key):
        if self._sync_lock: return
        v = int(scale.get_value())
        # Wymuś Safe jeśli safe_mode aktywne
        if self.state.tape.get("safe_mode", True):
            lim = SAFE_LIMITS.get(key, 100)
            if v > lim:
                v = lim
                self._sync_lock = True
                scale.set_value(v)
                self._sync_lock = False
        self.state.tape[key.lower()] = v
        self.fx.set_tape(self.state.tape)

    def _on_eq_preset(self, dd, *_):
        if self._sync_lock: return
        idx = dd.get_selected()
        name = list(EQ_PRESETS.keys())[idx]
        self.state.eq["preset"] = name
        bands = EQ_PRESETS[name]
        self.state.eq["bands"] = list(bands)
        self.dyn_eq.set_all_base(list(bands))
        self._sync_lock = True
        for i, s in enumerate(self.eq_sliders):
            s.set_value(bands[i])
        self._sync_lock = False

    def _on_dyn_mode(self, dd, *_):
        if self._sync_lock: return
        idx = dd.get_selected()
        mode = ["OFF", "AUTO", "BANDS"][idx]
        self.state.eq_dynamic["mode"] = mode
        self.dyn_eq.set_mode(mode)
        if mode == "AUTO":
            self.dyn_eq.set_all_base(self.state.eq.get("bands", [0]*10))

    def _on_dyn_depth(self, s):
        if self._sync_lock: return
        self.state.eq_dynamic["depth"] = float(s.get_value())
        self.dyn_eq.depth = float(s.get_value())

    def _on_dyn_smooth(self, s):
        if self._sync_lock: return
        self.state.eq_dynamic["smoothing"] = float(s.get_value())
        self.dyn_eq.smoothing = float(s.get_value())

    def _on_dyn_target(self, s):
        if self._sync_lock: return
        self.state.eq_dynamic["target"] = float(s.get_value())
        self.dyn_eq.target = float(s.get_value())

    def _on_eq_band(self, scale, i):
        if self._sync_lock: return
        v = float(scale.get_value())
        self.state.eq["bands"][i] = v
        self.dyn_eq.set_base_band(i, v)

    # _on_sp_active usunięte — Spatial FX zawsze aktywne, brak checkboxa.
    # Sterowanie tylko przez suwaki (_on_sp_slider).

    def _on_sp_slider(self, scale, key):
        if self._sync_lock: return
        v = int(scale.get_value())
        if key == "delay" and v > HIRES_HAAS_MAX_MS:
            v = HIRES_HAAS_MAX_MS
            self._sync_lock = True
            scale.set_value(v)
            self._sync_lock = False
        self.state.spatial[key] = v
        self.fx.set_spatial(self.state.spatial)

    def _on_ph_active(self, btn):
        if self._sync_lock: return
        self.state.phantom["active"] = btn.get_active()
        self.fx.set_phantom(self.state.phantom)

    def _on_ph_preset(self, dd, *_):
        if self._sync_lock: return
        idx = dd.get_selected()
        name = list(PHANTOM_PRESETS.keys())[idx]
        preset = PHANTOM_PRESETS[name]
        self.state.phantom["preset"] = name
        self.state.phantom["mode"] = preset["mode"]
        self.state.phantom["width"] = preset["width"]
        self.state.phantom["delay"] = min(preset["delay"], HIRES_HAAS_MAX_MS)
        self.state.phantom["blend"] = preset["blend"]
        self._sync_lock = True
        self.ph_sliders["width"].set_value(preset["width"])
        self.ph_sliders["delay"].set_value(self.state.phantom["delay"])
        self.ph_sliders["blend"].set_value(preset["blend"])
        self._sync_lock = False
        self._update_phantom_desc()
        self.fx.set_phantom(self.state.phantom)

    def _update_phantom_desc(self):
        idx = self.ph_preset_dd.get_selected()
        name = list(PHANTOM_PRESETS.keys())[idx]
        self.ph_desc.set_label(PHANTOM_PRESETS[name]["desc"])

    def _on_ph_slider(self, scale, key):
        if self._sync_lock: return
        v = int(scale.get_value())
        if key == "delay" and v > HIRES_HAAS_MAX_MS:
            v = HIRES_HAAS_MAX_MS
            self._sync_lock = True
            scale.set_value(v)
            self._sync_lock = False
        self.state.phantom[key] = v
        self.fx.set_phantom(self.state.phantom)

    def _on_ph_echo(self, scale):
        if self._sync_lock: return
        v = float(scale.get_value())
        self.state.phantom["echo_intensity"] = v
        self.fx.set_phantom(self.state.phantom)

    def _on_ap_toggle(self, btn):
        """GLOBAL AUTO PROTECT — włącza/wyłącza automatyczną ochronę na wszystkich
        3 limiter points. Gdy ON, manualne suwaki threshold są nadpisywane."""
        if self._sync_lock: return
        en = btn.get_active()
        self.state.limiter_auto_protect = en
        self.scenes.router.set_auto_protect_all(en)

    def _on_lim_point_enable(self, btn, pid):
        if self._sync_lock: return
        self.state.limiter[pid]["enabled"] = btn.get_active()
        if pid in self.scenes.router.points:
            mbl, _, _ = self.scenes.router.points[pid]
            mbl.set_enabled(btn.get_active())

    def _on_lim_band(self, scale, pid, col, prop):
        if self._sync_lock: return
        v = float(scale.get_value())
        bands = self.state.limiter[pid].setdefault("bands", [{} for _ in MBLIMIT_BANDS])
        while len(bands) <= col:
            bands.append({})
        bands[col][prop] = v
        if pid in self.scenes.router.points:
            mbl, _, _ = self.scenes.router.points[pid]
            if prop == "thr":
                mbl.set_band_threshold(col, v)
            else:
                mbl.set_band_ratio(col, v)
        # Jeśli POST_EQ — uaktualnij też tryb BANDS DynamicEQ
        if pid == "POST_EQ" and self.dyn_eq.mode == "BANDS":
            if prop == "thr":
                self.dyn_eq.set_band_threshold(col, v)
            else:
                self.dyn_eq.set_band_ratio(col, v)

    def _on_chain_enable(self, btn, mid):
        if self._sync_lock: return
        st = self.state.chain.setdefault(mid, {"enabled": False, "params": {}})
        st["enabled"] = btn.get_active()
        # FIXME: pełna obsługa chain modules — wymaga dynamicznego wstrzykiwania.
        # Na ten moment moduły chain są zapisywane w stanie sceny ale nie mają
        # dedykowanych elementów GStreamer (złożone wstrzykiwanie jak w carbONmp).
        print(f"[Chain] {mid} enabled={btn.get_active()} (zapisane w stanie)")

    def _on_chain_param(self, scale, mid, pname):
        if self._sync_lock: return
        v = float(scale.get_value())
        st = self.state.chain.setdefault(mid, {"enabled": False, "params": {}})
        st["params"][pname] = v
        print(f"[Chain] {mid}.{pname}={v}")

    # ── Scene bar handlers ────────────────────────────────────────────────
    def _on_scene_apply(self, *_):
        idx = self.scene_dd.get_selected()
        name = self.scenes.list_scenes()[idx]
        self.scenes.apply(name)
        self.sync_from_state()
        self._update_scene_desc(name)

    def _on_scene_save(self, *_):
        dlg = Gtk.Window(transient_for=self.get_root(), title="Zapisz scenę jako",
                         modal=True, default_width=320, default_height=140)
        dlg.set_child(self._scene_save_box(dlg))
        dlg.present()

    def _scene_save_box(self, dlg):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        box.set_margin_start(12); box.set_margin_end(12)
        box.set_margin_top(12);   box.set_margin_bottom(12)
        box.append(Gtk.Label(label="Nazwa sceny:"))
        entry = Gtk.Entry()
        entry.set_text("Moja scena")
        box.append(entry)
        btn_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        btn_row.set_halign(Gtk.Align.END)
        ok = Gtk.Button(label="Zapisz")
        cancel = Gtk.Button(label="Anuluj")
        cancel.connect("clicked", lambda *_: dlg.destroy())
        def _save(*_):
            name = entry.get_text().strip()
            if name:
                self.scenes.snapshot(name, icon="✨", desc="Własna scena użytkownika")
                self._refresh_scene_dd(select=name)
                dlg.destroy()
        ok.connect("clicked", _save)
        entry.connect("activate", _save)
        btn_row.append(cancel)
        btn_row.append(ok)
        box.append(btn_row)
        return box

    def _on_scene_export(self, *_):
        idx = self.scene_dd.get_selected()
        name = self.scenes.list_scenes()[idx]
        dlg = Gtk.FileChooserNative.new(
            "Eksportuj scenę", self.get_root(), Gtk.FileChooserAction.SAVE,
            "_Zapisz", "_Anuluj")
        dlg.set_modal(True)
        f = Gtk.FileFilter()
        f.set_name("JSON scene")
        f.add_pattern("*.json")
        dlg.add_filter(f)
        dlg.set_current_name(f"{name.replace(' ', '_').replace('/', '-')}.json")
        dlg.connect("response", lambda d, r: self._on_export_response(d, r, name))
        dlg.show()

    def _on_export_response(self, dlg, response, name):
        if response == Gtk.ResponseType.ACCEPT:
            path = dlg.get_file().get_path()
            self.scenes.export_scene(name, path)
        dlg.destroy()

    def _on_scene_import(self, *_):
        dlg = Gtk.FileChooserNative.new(
            "Importuj scenę", self.get_root(), Gtk.FileChooserAction.OPEN,
            "_Otwórz", "_Anuluj")
        dlg.set_modal(True)
        f = Gtk.FileFilter()
        f.set_name("JSON scene")
        f.add_pattern("*.json")
        dlg.add_filter(f)
        dlg.connect("response", lambda d, r: self._on_import_response(d, r))
        dlg.show()

    def _on_import_response(self, dlg, response):
        if response == Gtk.ResponseType.ACCEPT:
            path = dlg.get_file().get_path()
            name = self.scenes.import_scene(path)
            if name:
                self._refresh_scene_dd(select=name)
        dlg.destroy()

    def _on_scene_delete(self, *_):
        idx = self.scene_dd.get_selected()
        name = self.scenes.list_scenes()[idx]
        if self.scenes.is_builtin(name):
            print("[Scenes] nie można usunąć sceny wbudowanej")
            return
        self.scenes.delete(name)
        self._refresh_scene_dd()

    def _refresh_scene_dd(self, select=None):
        items = self.scenes.list_scenes()
        # Not ideal:DropDown nie ma natywnego API by zaktualizować listę stringów
        # w GTK4 — workaround: odbuduj model
        sm = Gtk.StringList.new(items)
        self.scene_dd.set_model(sm)
        if select and select in items:
            self.scene_dd.set_selected(items.index(select))
        # Odśwież user listbox
        # Usuń stare rowsy
        while self.user_listbox.get_first_child() is not None:
            first = self.user_listbox.get_first_child()
            self.user_listbox.remove(first)
        for name in self.scenes.list_user():
            self.user_listbox.append(self._scene_row(name, builtin=False))

    def _update_scene_desc(self, name):
        s = self.scenes.get(name)
        if s:
            self.scene_desc_lbl.set_label(s.get("meta", {}).get("desc", ""))

    # ── Sync UI z FXState ─────────────────────────────────────────────────
    def sync_from_state(self):
        """Aktualizuje wszystkie widgety panelu z self.state (po apply sceny)."""
        self._sync_lock = True
        try:
            # Tape
            self.tape_active.set_active(self.state.tape.get("active", False))
            self.tape_safe.set_active(self.state.tape.get("safe_mode", True))
            for key, lower in (("DRIVE", "drive"), ("WARMTH", "warmth"), ("COMP", "comp")):
                if key in self.tape_dials:
                    scale, _ = self.tape_dials[key]
                    v = self.state.tape.get(lower, 0)
                    if self.state.tape.get("safe_mode", True):
                        v = min(v, SAFE_LIMITS[key])
                    scale.set_value(v)
            # EQ
            eq_preset_list = list(EQ_PRESETS.keys())
            if self.state.eq.get("preset") in eq_preset_list:
                self.eq_preset_dd.set_selected(
                    eq_preset_list.index(self.state.eq["preset"]))
            bands = self.state.eq.get("bands", [0]*10)
            for i, s in enumerate(self.eq_sliders):
                s.set_value(bands[i] if i < len(bands) else 0)
            # Dynamic
            modes = ["OFF", "AUTO", "BANDS"]
            if self.state.eq_dynamic.get("mode") in modes:
                self.dyn_mode_dd.set_selected(modes.index(self.state.eq_dynamic["mode"]))
            self.dyn_depth.set_value(self.state.eq_dynamic.get("depth", 0.5))
            self.dyn_smooth.set_value(self.state.eq_dynamic.get("smoothing", 0.95))
            self.dyn_target.set_value(self.state.eq_dynamic.get("target", 0.4))
            # Spatial — zawsze aktywne, brak checkboxa. Tylko suwaki do sync.
            for key in ("width", "delay", "saturation"):
                if key in self.sp_sliders:
                    v = self.state.spatial.get(key, 0)
                    if key == "delay":
                        v = min(v, HIRES_HAAS_MAX_MS)
                    self.sp_sliders[key].set_value(v)
            # Phantom
            self.ph_active.set_active(self.state.phantom.get("active", False))
            preset_list = list(PHANTOM_PRESETS.keys())
            cur_preset = self.state.phantom.get("preset", "Off")
            if cur_preset in preset_list:
                self.ph_preset_dd.set_selected(preset_list.index(cur_preset))
            for key in ("width", "delay", "blend"):
                if key in self.ph_sliders:
                    v = self.state.phantom.get(key, 0)
                    if key == "delay":
                        v = min(v, HIRES_HAAS_MAX_MS)
                    self.ph_sliders[key].set_value(v)
            self.ph_echo.set_value(float(self.state.phantom.get("echo_intensity", 0.0)))
            self._update_phantom_desc()
            # Limiter — AUTO PROTECT toggle + per-point enable
            if hasattr(self, "ap_toggle"):
                self.ap_toggle.set_active(getattr(self.state, "limiter_auto_protect", True))
            for pid in LimiterRouter.POINTS:
                if pid in self.lim_widgets:
                    en = self.lim_widgets[pid]["enable"]
                    en.set_active(self.state.limiter.get(pid, {}).get("enabled", False))
        finally:
            self._sync_lock = False
        # Aplikuj stan do FX chain (po reload)
        self.fx.set_tape(self.state.tape)
        self.fx.set_eq_all(self.state.eq.get("bands", [0]*10))
        self.fx.set_spatial(self.state.spatial)
        self.fx.set_phantom(self.state.phantom)
        self.dyn_eq.set_mode(self.state.eq_dynamic.get("mode", "OFF"))


# ============================================================================
# FXController — fasada dla hearthis_player
# ============================================================================
class FXController:
    """Łączy wszystkie elementy modułu FX w jedną klasę dla wygody integracji
    w hearthis_player.py:

        from hearthis_fx import FXController
        self.fx_ctrl = FXController()
        # po zbudowaniu pipeline:
        self.fx_ctrl.attach_to_pipeline(pipeline, audioresample_el, volume_el)
        # panel GTK:
        panel = self.fx_ctrl.build_panel(app_ref=self)
        revealer = Gtk.Revealer(child=panel)
        # spectrum message z bus:
        self.fx_ctrl.on_bus_message(msg)
    """

    def __init__(self):
        self.state = FXState()
        self.fx = FXChain()
        self.dyn_eq = DynamicEQProcessor(self.fx)
        self.router = LimiterRouter()
        self.scenes = SceneManager(self.state, self.fx, self.dyn_eq, self.router)
        self.pipeline = None
        self._limiters_built = False
        self._entry_el = None
        self._exit_el = None

    # ── Pipeline attach ────────────────────────────────────────────────────
    def attach_to_pipeline(self, pipeline, entry_el, exit_el):
        """Buduje łańcuch FX i limity między entry_el a exit_el.
        entry_el — element z src padem (zwykle audioresample)
        exit_el  — element z sink padem (zwykle volume 'vol')

        Tworzy 3 MultibandLimity i rejestruje w routerze. Aplikuje aktualny stan.
        """
        self.pipeline = pipeline
        self._entry_el = entry_el
        self._exit_el = exit_el
        # Zbuduj łańcuch FX (tape → eq → spatial → phantom → conv_out)
        self.fx.build(pipeline, entry_el, exit_el)
        # MultibandLimiter POST_FX — między conv_out (ostatni element FX) a exit_el
        # Najpierw wstrzykuj MBL między conv_out (ostatni element FX) a exit_el
        # Jeśli conv_out nie istnieje (fallback), między entry a exit.
        mbl_anchor = self.fx.conv_out if self.fx.conv_out is not None else entry_el
        mbl_post_fx = MultibandLimiter(pipeline, "mbl_post_fx", MBLIMIT_BANDS)
        mbl_post_fx.inject(mbl_anchor, exit_el)
        # POST_EQ — między eq a sp_sat (lub między conv_out i MBL_POST_FX anchor jeśli eq brak)
        eq_anchor_out = self.fx.eq if self.fx.eq is not None else mbl_anchor
        eq_next = self.fx.sp_sat if self.fx.sp_sat is not None else mbl_anchor
        mbl_post_eq = MultibandLimiter(pipeline, "mbl_post_eq", MBLIMIT_BANDS)
        mbl_post_eq.inject(eq_anchor_out, eq_next)
        # INPUT — między entry_el a q_fx (lub między entry a tape_sat jeśli q_fx None)
        in_next = self.fx.q_fx if self.fx.q_fx is not None else self.fx.tape_sat
        if in_next is None:
            in_next = mbl_anchor
        mbl_input = MultibandLimiter(pipeline, "mbl_input", MBLIMIT_BANDS)
        mbl_input.inject(entry_el, in_next)
        # Rejestruj w routerze
        self.router.register("INPUT",   mbl_input,   entry_el, in_next)
        self.router.register("POST_EQ", mbl_post_eq, eq_anchor_out, eq_next)
        self.router.register("POST_FX", mbl_post_fx, mbl_anchor, exit_el)
        # DynEQ — ustaw referencję POST_EQ dla trybu BANDS
        self.dyn_eq.set_bands_limiter(mbl_post_eq)
        # Zbuduj dispatch table dla wiadomości `level` (AutoProtect)
        # Mapa: element_name → (mbl, band_i)
        self._level_dispatch = self.router.get_level_element_names()
        # Zastosuj aktualny stan
        self.fx.apply_neutral()
        self.scenes.apply(self.scenes.current) if self.scenes.current else None
        # Aplikuj stan domyślny jeśli brak sceny
        if not self.scenes.current:
            self.fx.set_tape(self.state.tape)
            self.fx.set_eq_all(self.state.eq.get("bands", [0]*10))
            self.fx.set_spatial(self.state.spatial)
            self.fx.set_phantom(self.state.phantom)
            self.router.apply(self.state.limiter)
        # AutoProtect — włącz jeśli flaga w stanie jest True (default)
        if getattr(self.state, "limiter_auto_protect", True):
            self.router.set_auto_protect_all(True)
        self._limiters_built = True

    def set_spectrum_element(self, spectrum_el):
        """Caller buduje osobną gałąź tee → spectrum → fakesink i przekazuje
        element spectrum tutaj (DynamicEQ potrzebuje jego wiadomości)."""
        self.fx.set_spectrum(spectrum_el)

    # ── Bus message handler ───────────────────────────────────────────────
    def on_bus_message(self, msg):
        """Wywoływane z bus callbacku playera. Dispatch:
           • spectrum → DynamicEQProcessor (tryb AUTO)
           • level    → MultibandLimiter.handle_level_message (AutoProtect)"""
        if msg.type == Gst.MessageType.ELEMENT:
            struct = msg.get_structure()
            if not struct:
                return
            sname = struct.get_name()
            if sname == "spectrum":
                self.dyn_eq.on_spectrum_message(struct)
            elif sname == "level":
                self._dispatch_level_message(msg, struct)

    def _dispatch_level_message(self, msg, struct):
        """Parsuje wiadomość `level` i dispatchuje do właściwego MBL.
        Element `level` emituje peak/rms jako GstValueList (dB per kanał)."""
        if not getattr(self, "_level_dispatch", None):
            return
        src = msg.src
        if src is None:
            return
        src_name = src.get_name()
        if src_name not in self._level_dispatch:
            return
        mbl, band_i = self._level_dispatch[src_name]
        # Parsuj peak i rms z wiadomości — GstValueList (lista dB per kanał)
        peak_db = self._parse_level_value(struct, "peak")
        rms_db  = self._parse_level_value(struct, "rms")
        try:
            mbl.handle_level_message(band_i, peak_db, rms_db)
        except Exception as e:
            # Nie groźne — level messages są ciągłe, pojedynczy błąd nie psuje
            pass

    @staticmethod
    def _parse_level_value(struct, field: str) -> float:
        """Parsuje pole `peak` lub `rms` z Gst.Structure wiadomości level.
        Wartości to GstValueList (dB per kanał). Zwraca max (najgłośniejszy kanał)."""
        try:
            v = struct.get_value(field)
            if v is None:
                return -80.0
            # GstValueList ma API nth() — użyj jeśli dostępne
            if hasattr(v, "nth"):
                # Gst.ValueList — liczenie przez length lub prób iteracji
                try:
                    n = v.length() if hasattr(v, "length") else 0
                    vals = [v.nth(i) for i in range(n)] if n else []
                except Exception:
                    vals = []
                if vals:
                    return max(vals)
            # Fallback: iterowalny (lista / tupla)
            if hasattr(v, "__iter__") and not isinstance(v, (str, bytes)):
                vals = list(v)
                if vals:
                    return max(vals)
            # Skalar
            return float(v)
        except Exception:
            return -80.0

    # ── Panel ──────────────────────────────────────────────────────────────
    def build_panel(self, app_ref=None) -> FXPanel:
        """Tworzy panel GTK4 z zakładkami — do włożenia w Gtk.Revealer."""
        self.scenes.app = app_ref
        return FXPanel(self.state, self.fx, self.dyn_eq, self.scenes, app_ref)

    # ── Apply scene by name (dla skrótów / CLI) ───────────────────────────
    def apply_scene(self, name: str) -> bool:
        ok = self.scenes.apply(name)
        return ok

    def list_scenes(self) -> list:
        return self.scenes.list_scenes()
